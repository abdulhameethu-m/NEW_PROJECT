const { ok } = require("../utils/apiResponse");
const { asyncHandler } = require("../utils/asyncHandler");
const webhookService = require("../services/webhook.service");

const razorpayWebhook = asyncHandler(async (req, res) => {
  const headerSig = req.headers["x-razorpay-signature"];
  const signature = Array.isArray(headerSig) ? headerSig[0] : headerSig;
  const rawBody = req.rawBody || (Buffer.isBuffer(req.body) ? req.body.toString("utf8") : (typeof req.body === "string" ? req.body : JSON.stringify(req.body || {})));
  const result = await webhookService.handleRazorpayWebhook(rawBody, signature);
  return ok(res, result);
});

const shiprocketWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers["x-shiprocket-signature"] || req.headers["x-logistics-signature"];
  const result = await webhookService.handleShiprocketWebhook(req.body, {
    rawBody: req.rawBody || JSON.stringify(req.body || {}),
    signature,
  });
  return ok(res, result);
});

const shadowfaxWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers["x-shadowfax-signature"] || req.headers["x-logistics-signature"];
  const result = await webhookService.handleShadowfaxWebhook(req.body, {
    rawBody: req.rawBody || JSON.stringify(req.body || {}),
    signature,
  });
  return ok(res, result);
});

const delhiveryWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers["x-delhivery-signature"]; // Some installations use tokens or headers
  const result = await webhookService.handleDelhiveryWebhook(req.body, {
    rawBody: req.rawBody || JSON.stringify(req.body || {}),
    signature,
  });
  return ok(res, result);
});

module.exports = { razorpayWebhook, shiprocketWebhook, shadowfaxWebhook, delhiveryWebhook };
