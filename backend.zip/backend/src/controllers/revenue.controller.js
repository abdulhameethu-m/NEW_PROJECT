const { ok } = require("../utils/apiResponse");
const { asyncHandler } = require("../utils/asyncHandler");
const { AppError } = require("../utils/AppError");
const revenueService = require("../services/revenue.service");

const getRevenueSummary = asyncHandler(async (req, res) => {
  const data = await revenueService.getRevenueSummary({
    startDate: req.query.startDate,
    endDate: req.query.endDate,
    vendorId: req.query.vendorId,
  });

  return ok(res, data, "Revenue summary loaded");
});

const getVendorRevenue = asyncHandler(async (req, res) => {
  const data = await revenueService.getVendorRevenueBreakdown({
    startDate: req.query.startDate,
    endDate: req.query.endDate,
    vendorId: req.query.vendorId,
    page: Number(req.query.page || 1),
    limit: Number(req.query.limit || 20),
  });

  return ok(res, data, "Vendor revenue loaded");
});

const exportRevenue = asyncHandler(async (req, res) => {
  const format = String(req.query.format || "csv").trim().toLowerCase();
  if (!["csv", "excel", "pdf"].includes(format)) {
    throw new AppError("Invalid export format", 400, "VALIDATION_ERROR");
  }

  const result = await revenueService.exportRevenueReport({
    format,
    startDate: req.query.startDate,
    endDate: req.query.endDate,
    vendorId: req.query.vendorId,
  });

  res.setHeader("Content-Type", result.contentType);
  res.setHeader("Content-Disposition", `attachment; filename="${result.filename}"`);
  res.send(result.buffer);
});

module.exports = {
  getRevenueSummary,
  getVendorRevenue,
  exportRevenue,
};
