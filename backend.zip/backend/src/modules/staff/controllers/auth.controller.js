const { ok } = require("../../../utils/apiResponse");
const { asyncHandler } = require("../../../utils/asyncHandler");
const staffAuthService = require("../services/staff-auth.service");
const { issueCsrfToken } = require("../../../middleware/csrf");

function cookieOptions(maxAgeMs) {
  const secure = process.env.NODE_ENV === "production";
  return {
    httpOnly: true,
    secure,
    sameSite: process.env.AUTH_COOKIE_SAMESITE || (secure ? "none" : "lax"),
    path: "/",
    maxAge: maxAgeMs,
  };
}

function setSessionCookies(res, result) {
  if (!result?.accessToken || !result?.refreshToken) return;
  const accessMaxAgeMs = Number(process.env.JWT_ACCESS_COOKIE_MAX_AGE_MS || 15 * 60 * 1000);
  const refreshMaxAgeMs = Number(process.env.JWT_REFRESH_TTL_DAYS || 30) * 24 * 60 * 60 * 1000;
  res.cookie("staffAccessToken", result.accessToken, cookieOptions(accessMaxAgeMs));
  res.cookie("staffRefreshToken", result.refreshToken, cookieOptions(refreshMaxAgeMs));
}

function clearSessionCookies(res) {
  res.clearCookie("staffAccessToken", cookieOptions(0));
  res.clearCookie("staffRefreshToken", cookieOptions(0));
}

function publicAuthPayload(result) {
  return { user: result?.user || null };
}

const login = asyncHandler(async (req, res) => {
  const result = await staffAuthService.login(req.body, {
    ipAddress: req.ip,
    userAgent: req.get("user-agent"),
  });
  setSessionCookies(res, result);
  issueCsrfToken(req, res);
  return ok(res, publicAuthPayload(result), "Staff logged in successfully");
});

const refresh = asyncHandler(async (req, res) => {
  const result = await staffAuthService.refreshSession(req.cookies?.staffRefreshToken, {
    ipAddress: req.ip,
    userAgent: req.get("user-agent"),
  });
  setSessionCookies(res, result);
  issueCsrfToken(req, res);
  return ok(res, publicAuthPayload(result), "Staff session refreshed");
});

const logout = asyncHandler(async (req, res) => {
  const result = await staffAuthService.logout(req.cookies?.staffRefreshToken);
  clearSessionCookies(res);
  return ok(res, result, "Staff logged out successfully");
});

const me = asyncHandler(async (req, res) => {
  const result = await staffAuthService.me(req.staff._id);
  return ok(res, result, "OK");
});

const csrf = asyncHandler(async (req, res) => {
  const csrfToken = issueCsrfToken(req, res);
  return ok(res, { csrfToken }, "CSRF token issued");
});

const requestPasswordReset = asyncHandler(async (req, res) => {
  const result = await staffAuthService.requestPasswordReset(req.body.email);
  return ok(res, result, "Password reset requested");
});

const resetPassword = asyncHandler(async (req, res) => {
  const result = await staffAuthService.resetPassword(req.body.token, req.body.password);
  return ok(res, result, "Password updated successfully");
});

/**
 * Request password reset OTP via email
 */
const requestPasswordResetOTP = asyncHandler(async (req, res) => {
  const result = await staffAuthService.requestPasswordResetOTP(req.body.identifier);
  return ok(res, result, "OTP sent to your email");
});

/**
 * Verify password reset OTP and get reset token
 */
const verifyPasswordResetOTP = asyncHandler(async (req, res) => {
  const result = await staffAuthService.verifyPasswordResetOTP(req.body.email, req.body.otp);
  return ok(res, result, "OTP verified successfully");
});

module.exports = {
  login,
  refresh,
  logout,
  me,
  csrf,
  requestPasswordReset,
  resetPassword,
  requestPasswordResetOTP,
  verifyPasswordResetOTP,
};
