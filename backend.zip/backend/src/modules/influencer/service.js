const userRepo = require("../../repositories/user.repository");
const notificationService = require("../../services/notification.service");
const bcrypt = require("bcryptjs");
const axios = require("axios");
const crypto = require("crypto");
const mongoose = require("mongoose");
const { AppError } = require("../../utils/AppError");
const { uploadMany } = require("../../utils/upload");
const { emitDomainEvent } = require("../events/event-bus");
const { INFLUENCER_EVENTS } = require("../shared/constants");
const { InfluencerWallet, CommissionRecord } = require("../commission/models");
const { Product } = require("../../models/Product");
const { User } = require("../../models/User");
const { Reel } = require("../reel/model");
const { Campaign } = require("../campaign/model");
const commissionRuleService = require("../../services/commission-rule.service");
const homepageLayoutService = require("../../services/homepage-layout.service");
const PrivateDocument = require("../../models/PrivateDocument");
const {
  InfluencerApplication,
  InfluencerProfile,
  InfluencerBusinessProfile,
  InfluencerPaymentProfile,
  InfluencerApplicationDocument,
  InfluencerApplicationReview,
  InfluencerBadge,
  InfluencerStorefront,
  InfluencerAffiliateSetting,
  InfluencerProductAssignment,
  AffiliateLink,
  InfluencerCollection,
  InfluencerActivationAudit,
  InfluencerSocialAccount,
  InfluencerSocialVerification,
  InfluencerFollower,
  InfluencerPost,
  InfluencerNewsletterSubscription,
  InfluencerStorefrontEvent,
} = require("./model");

const DEFAULT_SOCIAL_REQUIREMENTS = {
  instagram: { minFollowers: 1000, minEngagementRate: 2 },
  youtube: { minFollowers: 500, minEngagementRate: 2 },
  tiktok: { minFollowers: 1000, minEngagementRate: 2 },
  default: { minFollowers: 0, minEngagementRate: 0 },
};
const DEFAULT_COMMISSION_SETTINGS = {
  commissionPercentage: Number(process.env.INFLUENCER_DEFAULT_COMMISSION_PERCENT || 10),
  commissionModel: process.env.INFLUENCER_DEFAULT_COMMISSION_MODEL || "Per Sale",
  minimumPayoutThreshold: Number(process.env.INFLUENCER_MIN_PAYOUT_THRESHOLD || 500),
  payoutSchedule: process.env.INFLUENCER_PAYOUT_SCHEDULE || "Monthly",
  currency: process.env.DEFAULT_CURRENCY || "INR",
};

const COUNTRY_MASTER = [
  { code: "IN", name: "India", states: [{ name: "Tamil Nadu", cities: ["Coimbatore", "Chennai", "Madurai"] }, { name: "Karnataka", cities: ["Bengaluru", "Mysuru"] }, { name: "Maharashtra", cities: ["Mumbai", "Pune"] }] },
  { code: "US", name: "United States", states: [{ name: "California", cities: ["Los Angeles", "San Francisco"] }, { name: "New York", cities: ["New York"] }] },
  { code: "AE", name: "United Arab Emirates", states: [{ name: "Dubai", cities: ["Dubai"] }, { name: "Abu Dhabi", cities: ["Abu Dhabi"] }] },
  { code: "GB", name: "United Kingdom", states: [{ name: "England", cities: ["London", "Manchester"] }] },
];

function cleanString(value = "") {
  return String(value || "").trim();
}

function normalizeEmail(value = "") {
  return cleanString(value).toLowerCase();
}

function normalizeUsername(value = "") {
  return cleanString(value).toLowerCase();
}

function sanitizeApplication(application) {
  if (!application) return null;
  return {
    id: application._id,
    applicationId: application.applicationId,
    firstName: application.firstName,
    lastName: application.lastName,
    email: application.email,
    mobile: application.mobile,
    username: application.username,
    referralCode: application.referralCode || "",
    status: application.status,
    currentStep: application.currentStep,
    applicationNumber: application.applicationNumber || "",
    reviewStage: application.reviewStage || "",
    creatorScore: application.creatorScore || 0,
    submittedAt: application.submittedAt || null,
    reviewedAt: application.reviewedAt || null,
    approvedAt: application.approvedAt || null,
    rejectedAt: application.rejectedAt || null,
    reviewNotes: application.reviewNotes || "",
    profileDraft: application.profileDraft || {},
    createdAt: application.createdAt,
    updatedAt: application.updatedAt,
  };
}

function sanitizeSocialAccount(account) {
  if (!account) return null;
  return {
    id: account._id,
    applicationId: account.applicationId,
    influencerId: account.influencerId || null,
    platform: account.platform,
    platformLabel: account.platformLabel || "",
    profileUrl: account.profileUrl,
    username: account.username || "",
    channelName: account.channelName || "",
    accountType: account.accountType || "",
    followersCount: Number(account.followersCount || 0),
    engagementRate: Number(account.engagementRate || 0),
    description: account.description || "",
    metrics: account.metrics || {},
    verificationStatus: account.verificationStatus,
    verifiedAt: account.verifiedAt || null,
    createdAt: account.createdAt,
    updatedAt: account.updatedAt,
  };
}

function sanitizeVerification(verification) {
  if (!verification) return null;
  return {
    id: verification._id,
    socialAccountId: verification.socialAccountId,
    applicationId: verification.applicationId,
    verificationMethod: verification.verificationMethod,
    verificationCode: verification.verificationCode || "",
    screenshotPath: verification.screenshotPath || "",
    status: verification.status,
    reviewNotes: verification.reviewNotes || "",
    createdAt: verification.createdAt,
    updatedAt: verification.updatedAt,
  };
}

function normalizePlatform(value = "") {
  return cleanString(value).toLowerCase().replace(/[^a-z0-9_]/g, "_").replace(/_+/g, "_").slice(0, 40);
}

function normalizeUrl(value = "") {
  const input = cleanString(value);
  if (!input) return "";
  try {
    const url = new URL(input);
    url.hash = "";
    return url.toString();
  } catch {
    return input;
  }
}

function extractSocialUsername(platform, profileUrl = "") {
  try {
    const url = new URL(profileUrl);
    const parts = url.pathname.split("/").map((part) => part.trim()).filter(Boolean);
    if (platform === "instagram") return (parts[0] || "").replace(/^@/, "");
    if (platform === "youtube") return (parts[0] === "@" ? parts[1] : parts[0] || "").replace(/^@/, "");
    return (parts[0] || "").replace(/^@/, "");
  } catch {
    return "";
  }
}

function makeVerificationCode(applicationId, platform) {
  const seed = `${applicationId}:${platform}:${Date.now()}:${crypto.randomBytes(4).toString("hex")}`;
  const suffix = crypto.createHash("sha1").update(seed).digest("hex").slice(0, 4).toUpperCase();
  return `INFLUENCER-GRM-${suffix}`;
}

function calculateCreatorScore(accounts = []) {
  const activeAccounts = accounts.filter((account) => account.profileUrl);
  const totalFollowers = activeAccounts.reduce((sum, account) => sum + Number(account.followersCount || 0), 0);
  const averageEngagement = activeAccounts.length
    ? activeAccounts.reduce((sum, account) => sum + Number(account.engagementRate || 0), 0) / activeAccounts.length
    : 0;
  const contentTotal = activeAccounts.reduce((sum, account) => sum + Number(account.metrics?.contentCount || 0), 0);
  const followersScore = Math.min(35, Math.round(Math.log10(totalFollowers + 1) * 8));
  const engagementScore = Math.min(30, Math.round(averageEngagement * 6));
  const consistencyScore = Math.min(20, Math.round(contentTotal / 10));
  const diversityScore = Math.min(15, activeAccounts.length * 4);
  const score = Math.min(100, followersScore + engagementScore + consistencyScore + diversityScore);
  const level = score >= 80 ? "Gold Creator" : score >= 60 ? "Silver Creator" : score >= 40 ? "Rising Creator" : "Starter Creator";
  return { score, level, followersScore, engagementScore, consistencyScore, diversityScore };
}

function calculateApplicationScore({ application, socialAccounts = [], business, payment, sampleCount = 0, identityCount = 0 } = {}) {
  const verifiedSocial = socialAccounts.filter((account) => ["verified", "under_review", "manual_review_required"].includes(account.verificationStatus));
  const totalFollowers = socialAccounts.reduce((sum, account) => sum + Number(account.followersCount || 0), 0);
  const averageEngagement = socialAccounts.length
    ? socialAccounts.reduce((sum, account) => sum + Number(account.engagementRate || 0), 0) / socialAccounts.length
    : 0;
  const contentQuality = Math.min(100, 45 + sampleCount * 12);
  const audienceQuality = Math.min(100, Math.round(Math.log10(totalFollowers + 1) * 18));
  const engagement = Math.min(100, Math.round(averageEngagement * 12));
  const requiredProfileFields = ["profilePicture", "coverBanner", "displayName", "shortBio", "primaryCategory", "storeSlug"];
  const profileCompleteness = Math.round(
    (requiredProfileFields.filter((field) => application?.profileDraft?.[field]).length / requiredProfileFields.length) * 100
  );
  const verification = Math.min(100, (verifiedSocial.length ? 40 : 0) + (business ? 20 : 0) + (payment ? 20 : 0) + (identityCount ? 20 : 0));
  const overall = Math.round((contentQuality * 0.25) + (audienceQuality * 0.2) + (engagement * 0.2) + (profileCompleteness * 0.2) + (verification * 0.15));
  const level = overall >= 80 ? "Gold Creator" : overall >= 60 ? "Silver Creator" : overall >= 40 ? "Rising Creator" : "Starter Creator";
  return { contentQuality, audienceQuality, engagement, profileCompleteness, verification, overall, level };
}

function parseList(value, max = 20) {
  if (Array.isArray(value)) return value.map(cleanString).filter(Boolean).slice(0, max);
  if (typeof value !== "string") return [];
  try {
    const parsed = JSON.parse(value);
    if (Array.isArray(parsed)) return parsed.map(cleanString).filter(Boolean).slice(0, max);
  } catch {
    // fall through to comma split
  }
  return value.split(",").map(cleanString).filter(Boolean).slice(0, max);
}

function parseJsonObject(value, fallback = {}) {
  if (value && typeof value === "object" && !Array.isArray(value)) return value;
  if (typeof value !== "string" || !value.trim()) return fallback;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function parseJsonArray(value, fallback = []) {
  if (Array.isArray(value)) return value;
  if (typeof value !== "string" || !value.trim()) return fallback;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function slugify(value = "") {
  return cleanString(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function normalizeCollectionType(value = "custom") {
  const next = cleanString(value).toLowerCase();
  const map = {
    custom_collection: "custom",
    featured_collection: "featured",
    seasonal_collection: "seasonal",
    campaign_collection: "campaign",
    affiliate_collection: "affiliate",
    trending_collection: "trending_products",
    bundle_collection: "bundle",
    brand_collection: "brand",
  };
  return map[next] || next || "custom";
}

function normalizeCollectionStatus(value = "draft") {
  const next = cleanString(value).toLowerCase();
  if (next === "published") return "active";
  return ["active", "draft", "archived", "scheduled"].includes(next) ? next : "draft";
}

function normalizeTags(value = []) {
  return Array.from(new Set((Array.isArray(value) ? value : String(value || "").split(","))
    .map((item) => cleanString(item).toLowerCase())
    .filter(Boolean)
    .slice(0, 20)));
}

function productImage(product = {}) {
  const first = Array.isArray(product.images) ? product.images[0] : null;
  return product.thumbnail || (typeof first === "string" ? first : first?.url) || "";
}

function collectionAnalyticsSnapshot(collection = {}) {
  const analytics = collection.analytics || {};
  const clicks = Number(analytics.clicks || 0);
  const views = Number(analytics.views || 0);
  const orders = Number(analytics.orders || 0);
  return {
    views,
    uniqueVisitors: Number(analytics.uniqueVisitors || 0),
    clicks,
    ctr: views ? Number(((clicks / views) * 100).toFixed(2)) : 0,
    orders,
    revenue: Number(analytics.revenue || 0),
    commission: Number(analytics.commission || 0),
    conversionRate: clicks ? Number(((orders / clicks) * 100).toFixed(2)) : 0,
    shares: Number(analytics.shares || 0),
    saves: Number(analytics.saves || 0),
  };
}

function compactProfileStats({ profile = {}, reels = [], followerCount = 0, followingCount = 0, orderCount = 0 }) {
  const reelLikes = reels.reduce((sum, reel) => sum + Number(reel.metrics?.likes || 0), 0);
  return {
    followers: Number(followerCount || profile.followers || 0),
    following: Number(followingCount || 0),
    totalLikes: Number(reelLikes || 0),
    ordersGenerated: Number(orderCount || profile.stats?.sales || 0),
    profileViews: Number(profile.stats?.views || 0),
    productClicks: Number(profile.stats?.clicks || 0),
    revenue: Number(profile.stats?.revenue || 0),
  };
}

function publicProductSelect() {
  return "name slug images thumbnail category price discountPrice ratings analytics status isActive stock sellerId variants";
}

function collectPublicSocialLinks(storefront = {}, profile = {}, accounts = []) {
  const fromStorefront = storefront.socialLinks || {};
  const fromProfile = profile.socialHandles || {};
  const links = {};
  Object.entries(fromStorefront).forEach(([key, value]) => {
    const url = typeof value === "string" ? value : value?.url || value?.profileUrl || "";
    if (url) links[key.toLowerCase()] = { platform: key.toLowerCase(), url };
  });
  Object.entries(fromProfile).forEach(([key, value]) => {
    if (value && !links[key.toLowerCase()]) links[key.toLowerCase()] = { platform: key.toLowerCase(), url: value };
  });
  accounts.forEach((account) => {
    if (account.profileUrl) links[account.platform] = {
      platform: account.platform,
      url: account.profileUrl,
      username: account.username,
      followers: account.followersCount,
    };
  });
  return Object.values(links);
}

function buildStructuredData({ profile = {}, user = {}, storefront = {}, collections = [], featuredProducts = [] }) {
  const displayName = profile.displayName || user.name || storefront.name || "Creator";
  return {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    name: displayName,
    url: `/influencer/${storefront.slug || profile.storeSlug || ""}`,
    mainEntity: {
      "@type": "Person",
      name: displayName,
      image: storefront.profileImage || profile.profilePicture || user.avatarUrl || "",
      description: storefront.description || profile.longBio || profile.bio || profile.shortBio || "",
      sameAs: collectPublicSocialLinks(storefront, profile).map((link) => link.url),
    },
    hasPart: [
      ...collections.slice(0, 6).map((collection) => ({
        "@type": "CollectionPage",
        name: collection.title,
        url: `/influencer/${storefront.slug || profile.storeSlug || ""}/collections#${collection.slug}`,
      })),
      ...featuredProducts.slice(0, 6).map((product) => ({
        "@type": "Product",
        name: product.name,
        image: product.thumbnail || product.images?.[0]?.url || "",
      })),
    ],
  };
}

function escapeRegex(value = "") {
  return cleanString(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function enrichAffiliateProduct(product = {}, profile = null) {
  const price = Number(product.discountPrice || product.price || 0);
  let commission = { commissionValue: 0, commissionAmount: 0, commissionType: "percentage" };
  try {
    commission = await commissionRuleService.calculateForOrderItem({
      productId: product._id,
      vendorId: product.sellerId?._id || product.sellerId,
      categoryId: product.categoryId,
      subtotal: price,
    });
  } catch {
    commission = {
      commissionType: "percentage",
      commissionValue: profile?.affiliate?.commissionRate || 0,
      commissionAmount: Number(((price * Number(profile?.affiliate?.commissionRate || 0)) / 100).toFixed(2)),
    };
  }
  const views = Number(product.analytics?.views || 0);
  const sales = Number(product.analytics?.salesCount || 0);
  const revenue = Number(product.analytics?.totalRevenue || 0);
  return {
    id: String(product._id),
    _id: product._id,
    name: product.name,
    sku: product.SKU,
    image: productImage(product),
    brand: product.sellerId?.shopName || product.sellerId?.companyName || "",
    vendor: product.sellerId?.shopName || product.sellerId?.companyName || "",
    category: product.category,
    categoryId: product.categoryId,
    price: Number(product.price || 0),
    salePrice: price,
    commissionRate: Number(commission.commissionValue || 0),
    commissionType: commission.commissionType,
    commissionAmount: Number(commission.commissionAmount || 0),
    rating: Number(product.ratings?.averageRating || 0),
    reviewsCount: Number(product.ratings?.totalReviews || 0),
    salesVolume: sales,
    views,
    revenue,
    conversionRate: views ? Number(((sales / views) * 100).toFixed(2)) : 0,
    stockStatus: Number(product.stock || 0) > 0 ? "In Stock" : "Out of Stock",
    stock: Number(product.stock || 0),
    status: product.status,
    createdAt: product.createdAt,
    recommendationScore: product.recommendationScore || 0,
    trendScore: Number((views * 0.2 + sales * 3 + revenue * 0.01).toFixed(2)),
  };
}

const PROMOTION_ASSIGNMENT_STATUSES = ["assigned", "accepted", "approved", "active"];
const PROMOTION_CAMPAIGN_STATES = ["active", "accepted", "completed"];

function applicationApprovedFor(campaign = {}, influencerId) {
  return (campaign.applications || []).some((application) => (
    String(application.influencerId?._id || application.influencerId) === String(influencerId) &&
    ["approved"].includes(String(application.status || "").toLowerCase())
  ));
}

async function upsertCampaignProductAssignments({ influencerId, vendorId, campaignId, productIds = [], status = "approved", source = "vendor_campaign", actorId = null }) {
  const now = new Date();
  await Promise.all((productIds || []).filter(Boolean).map((productId) => InfluencerProductAssignment.findOneAndUpdate(
    { influencerId, productId, campaignId: campaignId || null },
    {
      $set: {
        influencerId,
        vendorId,
        productId,
        campaignId: campaignId || undefined,
        status,
        source,
        ...(status === "accepted" ? { acceptedAt: now } : {}),
        ...(status === "approved" || status === "active" ? { approvedAt: now } : {}),
        "metadata.lastActorId": actorId || undefined,
      },
      $setOnInsert: { assignedAt: now },
    },
    { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
  )));
}

async function getEligiblePromotionProductContext(influencerId) {
  const [assignments, campaigns] = await Promise.all([
    InfluencerProductAssignment.find({ influencerId, status: { $in: PROMOTION_ASSIGNMENT_STATUSES } })
      .populate("campaignId", "title state commissionPercent")
      .populate("vendorId", "shopName companyName")
      .lean(),
    Campaign.find({
      productIds: { $exists: true, $ne: [] },
      $or: [
        { influencerId, state: { $in: PROMOTION_CAMPAIGN_STATES } },
        { applications: { $elemMatch: { influencerId, status: "approved" } } },
      ],
    }).select("_id title state vendorId productIds commissionPercent applications influencerId")
      .populate("vendorId", "shopName companyName")
      .lean(),
  ]);
  const byProduct = new Map();
  const productIds = new Set();
  for (const assignment of assignments) {
    const key = String(assignment.productId);
    productIds.add(key);
    byProduct.set(key, {
      assignmentId: assignment._id,
      promotionStatus: assignment.status,
      source: assignment.source,
      campaignId: assignment.campaignId?._id || assignment.campaignId || "",
      campaignName: assignment.campaignId?.title || "",
      campaignStatus: assignment.campaignId?.state || "",
      vendorId: assignment.vendorId?._id || assignment.vendorId || "",
      vendorName: assignment.vendorId?.shopName || assignment.vendorId?.companyName || "",
    });
  }
  for (const campaign of campaigns) {
    const ownsCampaign = String(campaign.influencerId || "") === String(influencerId);
    if (!ownsCampaign && !applicationApprovedFor(campaign, influencerId)) continue;
    for (const productId of campaign.productIds || []) {
      const key = String(productId);
      productIds.add(key);
      if (!byProduct.has(key)) {
        byProduct.set(key, {
          promotionStatus: ownsCampaign ? "accepted" : "approved",
          source: ownsCampaign ? "influencer_acceptance" : "campaign_application",
          campaignId: campaign._id,
          campaignName: campaign.title,
          campaignStatus: campaign.state,
          campaignCommissionPercent: campaign.commissionPercent,
          vendorId: campaign.vendorId?._id || campaign.vendorId || "",
          vendorName: campaign.vendorId?.shopName || campaign.vendorId?.companyName || "",
        });
      }
    }
  }
  return { productIds: [...productIds], byProduct };
}

async function assertPromotionProductAllowed(influencerId, productId, campaignId = "") {
  const context = await getEligiblePromotionProductContext(influencerId);
  const meta = context.byProduct.get(String(productId));
  if (!meta) throw new AppError("Product is not assigned or approved for this influencer", 403, "PRODUCT_NOT_APPROVED_FOR_INFLUENCER");
  if (campaignId && meta.campaignId && String(meta.campaignId) !== String(campaignId)) {
    throw new AppError("Product is not approved for the selected campaign", 403, "PRODUCT_NOT_APPROVED_FOR_CAMPAIGN");
  }
  return meta;
}

function encryptionKey() {
  return crypto.createHash("sha256").update(process.env.DATA_ENCRYPTION_KEY || process.env.JWT_SECRET || "dev-influencer-key").digest();
}

function encryptSensitive(value = "") {
  const text = cleanString(value);
  if (!text) return "";
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("hex")}:${tag.toString("hex")}:${encrypted.toString("hex")}`;
}

function decryptSensitive(encryptedData = "") {
  if (!encryptedData || typeof encryptedData !== "string") return "";
  const parts = encryptedData.split(":");
  if (parts.length !== 3) return "";
  try {
    const iv = Buffer.from(parts[0], "hex");
    const tag = Buffer.from(parts[1], "hex");
    const text = Buffer.from(parts[2], "hex");
    const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), iv);
    decipher.setAuthTag(tag);
    const decrypted = Buffer.concat([decipher.update(text), decipher.final()]);
    return decrypted.toString("utf8");
  } catch (err) {
    return "";
  }
}

function maskAccount(value = "") {
  const text = cleanString(value);
  if (!text) return "";
  return `${"X".repeat(Math.max(0, text.length - 4))}${text.slice(-4)}`;
}

function sanitizeBusinessPayload(payload = {}, uploaded = {}) {
  return {
    country: cleanString(payload.country),
    state: cleanString(payload.state),
    city: cleanString(payload.city),
    address1: cleanString(payload.address1),
    address2: cleanString(payload.address2),
    postalCode: cleanString(payload.postalCode),
    businessType: cleanString(payload.businessType),
    customBusinessType: cleanString(payload.customBusinessType),
    gstNumber: cleanString(payload.gstNumber).toUpperCase(),
    panNumber: cleanString(payload.panNumber).toUpperCase(),
    taxId: cleanString(payload.taxId),
    businessRegistrationNumber: cleanString(payload.businessRegistrationNumber),
    legalName: cleanString(payload.legalName),
    businessName: cleanString(payload.businessName),
    dateOfBirth: cleanString(payload.dateOfBirth),
    nationality: cleanString(payload.nationality),
    documents: uploaded,
  };
}

function validateBusiness(payload = {}) {
  const required = ["country", "state", "city", "address1", "postalCode", "legalName", "dateOfBirth", "nationality"];
  for (const field of required) {
    if (!payload[field]) throw new AppError(`${field} is required`, 400, "VALIDATION_ERROR");
  }
  if (payload.country === "IN") {
    if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(payload.panNumber)) throw new AppError("Valid PAN number is required for India", 400, "VALIDATION_ERROR");
    if (payload.gstNumber && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(payload.gstNumber)) throw new AppError("GST number format is invalid", 400, "VALIDATION_ERROR");
  } else if (!payload.taxId) {
    throw new AppError("Tax ID is required for selected country", 400, "VALIDATION_ERROR");
  }
}

function sanitizePaymentPayload(payload = {}) {
  return {
    payoutMethod: cleanString(payload.payoutMethod),
    accountHolderName: cleanString(payload.accountHolderName),
    bankName: cleanString(payload.bankName),
    branchName: cleanString(payload.branchName),
    accountNumber: cleanString(payload.accountNumber).replace(/[\s-]/g, ""),
    confirmAccountNumber: cleanString(payload.confirmAccountNumber).replace(/[\s-]/g, ""),
    ifscCode: cleanString(payload.ifscCode).toUpperCase(),
    swiftCode: cleanString(payload.swiftCode).toUpperCase(),
    routingNumber: cleanString(payload.routingNumber),
    upiId: cleanString(payload.upiId),
    paypalEmail: cleanString(payload.paypalEmail).toLowerCase(),
    payoneerEmail: cleanString(payload.payoneerEmail).toLowerCase(),
    agreements: parseJsonObject(payload.agreements, payload.agreements || {}),
    country: cleanString(payload.country),
  };
}

function validatePayment(payload = {}, existingPayment = null) {
  if (!payload.payoutMethod) throw new AppError("Payout method is required", 400, "VALIDATION_ERROR");
  if (payload.payoutMethod === "bank_transfer") {
    const hasSavedAccount = Boolean(existingPayment?.accountNumberEncrypted && !payload.accountNumber && !payload.confirmAccountNumber);
    if (!payload.accountHolderName || !payload.bankName || (!payload.accountNumber && !hasSavedAccount)) throw new AppError("Bank account details are required", 400, "VALIDATION_ERROR");
    if (!hasSavedAccount && payload.accountNumber !== payload.confirmAccountNumber) throw new AppError("Account numbers must match", 400, "VALIDATION_ERROR");
    if (payload.country === "IN" && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(payload.ifscCode)) throw new AppError("IFSC code is invalid", 400, "VALIDATION_ERROR");
    if (payload.country !== "IN" && !payload.swiftCode) throw new AppError("SWIFT code is required for international transfers", 400, "VALIDATION_ERROR");
  }
  if (payload.payoutMethod === "upi" && !/^[\w.-]+@[\w.-]+$/.test(payload.upiId)) throw new AppError("UPI ID is invalid", 400, "VALIDATION_ERROR");
  if (!payload.agreements?.payoutPolicy || !payload.agreements?.commissionTerms || !payload.agreements?.taxCompliance) {
    throw new AppError("Payment agreements are required", 400, "VALIDATION_ERROR");
  }
}

function sanitizeProfileDraftPayload(payload = {}, uploaded = {}) {
  const mediaTransforms = parseJsonObject(payload.mediaTransforms);
  const displayName = cleanString(payload.displayName);
  const storeName = cleanString(payload.storeName) || displayName;
  return {
    profilePicture: uploaded.profilePicture || cleanString(payload.profilePicture),
    coverBanner: uploaded.coverBanner || cleanString(payload.coverBanner),
    displayName,
    shortBio: cleanString(payload.shortBio),
    longBio: cleanString(payload.longBio),
    primaryCategory: cleanString(payload.primaryCategory),
    customCategory: cleanString(payload.customCategory),
    secondaryCategories: parseList(payload.secondaryCategories, 5),
    languages: parseList(payload.languages, 12),
    country: cleanString(payload.country),
    state: cleanString(payload.state),
    city: cleanString(payload.city),
    website: cleanString(payload.website),
    contentNiche: parseList(payload.contentNiche, 12),
    contentStyle: parseList(payload.contentStyle, 12),
    storeName,
    storeSlug: slugify(payload.storeSlug || storeName),
    metaTitle: cleanString(payload.metaTitle),
    metaDescription: cleanString(payload.metaDescription),
    socialSharingImage: uploaded.socialSharingImage || cleanString(payload.socialSharingImage),
    mediaTransforms: {
      profilePicture: {
        zoom: Number(mediaTransforms?.profilePicture?.zoom || 1),
        rotation: Number(mediaTransforms?.profilePicture?.rotation || 0),
      },
      coverBanner: {
        zoom: Number(mediaTransforms?.coverBanner?.zoom || 1),
        rotation: Number(mediaTransforms?.coverBanner?.rotation || 0),
      },
    },
  };
}

function sanitizeProfileDraft(application) {
  const draft = application?.profileDraft || {};
  return {
    applicationId: application?.applicationId,
    currentStep: application?.currentStep,
    profile: {
      profilePicture: draft.profilePicture || "",
      coverBanner: draft.coverBanner || "",
      displayName: draft.displayName || "",
      shortBio: draft.shortBio || "",
      longBio: draft.longBio || "",
      primaryCategory: draft.primaryCategory || "",
      customCategory: draft.customCategory || "",
      secondaryCategories: draft.secondaryCategories || [],
      languages: draft.languages || [],
      country: draft.country || "",
      state: draft.state || "",
      city: draft.city || "",
      website: draft.website || "",
      contentNiche: draft.contentNiche || [],
      contentStyle: draft.contentStyle || [],
      storeName: draft.storeName || "",
      storeSlug: draft.storeSlug || "",
      metaTitle: draft.metaTitle || "",
      metaDescription: draft.metaDescription || "",
      socialSharingImage: draft.socialSharingImage || "",
      mediaTransforms: draft.mediaTransforms || {},
    },
    updatedAt: application?.updatedAt,
  };
}

function validateProfileForContinue(profile = {}) {
  if (!profile.profilePicture) throw new AppError("Profile picture is required", 400, "VALIDATION_ERROR");
  if (!profile.coverBanner) throw new AppError("Cover banner is required", 400, "VALIDATION_ERROR");
  if (profile.displayName.length < 3 || profile.displayName.length > 100) {
    throw new AppError("Display name must be between 3 and 100 characters", 400, "VALIDATION_ERROR");
  }
  if (profile.shortBio.length < 20 || profile.shortBio.length > 160) {
    throw new AppError("Short bio must be between 20 and 160 characters", 400, "VALIDATION_ERROR");
  }

  if (!profile.storeSlug) throw new AppError("Influencer URL slug is required", 400, "VALIDATION_ERROR");
}

function validateSocialPayload(accounts = []) {
  const errors = [];
  const seenPlatforms = new Set();
  const seenUrls = new Set();
  for (const [index, account] of accounts.entries()) {
    const platform = normalizePlatform(account.platform);
    const url = normalizeUrl(account.profileUrl);
    if (!platform) errors.push(`Social profile ${index + 1} requires a platform.`);
    if (!url) errors.push(`${account.platformLabel || platform || "Profile"} URL is required.`);
    try {
      if (url) new URL(url);
    } catch {
      errors.push(`${account.platformLabel || platform || "Profile"} URL must be valid.`);
    }
    if (platform && seenPlatforms.has(platform)) errors.push(`Duplicate platform entry: ${account.platformLabel || platform}.`);
    if (url && seenUrls.has(url)) errors.push(`Duplicate profile URL: ${url}.`);
    seenPlatforms.add(platform);
    seenUrls.add(url);
  }
  if (errors.length) throw new AppError(errors[0], 400, "VALIDATION_ERROR", { issues: errors });
}

function generateApplicationId() {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const suffix = crypto.randomBytes(4).toString("hex").toUpperCase();
  return `INF-${date}-${suffix}`;
}

function generateApplicationNumber() {
  const year = new Date().getFullYear();
  const suffix = crypto.randomBytes(4).readUInt32BE(0).toString().padStart(10, "0").slice(0, 8);
  return `INF-${year}-${suffix}`;
}

function generateInfluencerCode() {
  return `INF${crypto.randomBytes(4).readUInt32BE(0).toString().padStart(10, "0").slice(0, 8)}`;
}

function generateTrackingCode(username = "") {
  const base = slugify(username || "creator").replace(/-/g, "").slice(0, 12) || "creator";
  return `${base}${crypto.randomBytes(2).toString("hex")}`.toLowerCase();
}

async function ensureUniqueInfluencerCode() {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = generateInfluencerCode();
    const exists = await InfluencerProfile.exists({ influencerCode: code });
    if (!exists) return code;
  }
  throw new AppError("Could not generate a unique influencer code", 409, "INFLUENCER_CODE_COLLISION");
}

async function ensureUniqueStoreSlug(baseSlug, userId = null) {
  const base = slugify(baseSlug || "creator") || `creator-${crypto.randomBytes(3).toString("hex")}`;
  for (let attempt = 0; attempt < 25; attempt += 1) {
    const slug = attempt === 0 ? base : `${base}-${attempt + 1}`;
    const [profile, storefront] = await Promise.all([
      InfluencerProfile.findOne({ storeSlug: slug, ...(userId ? { userId: { $ne: userId } } : {}) }).select("_id").lean(),
      InfluencerStorefront.findOne({ slug }).select("_id influencerId").lean(),
    ]);
    if (!profile && !storefront) return slug;
  }
  return `${base}-${crypto.randomBytes(4).toString("hex")}`;
}

async function ensureUniqueTrackingCode(username = "") {
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const code = generateTrackingCode(username);
    const exists = await InfluencerAffiliateSetting.exists({ trackingCode: code });
    if (!exists) return code;
  }
  return `${slugify(username || "creator").replace(/-/g, "").slice(0, 10)}${crypto.randomBytes(5).toString("hex")}`;
}

async function writeActivationAudit(payload = {}) {
  try {
    await InfluencerActivationAudit.create(payload);
  } catch {
    // Audit writes should not break idempotent activation retries.
  }
}

function documentCategoryFor(type = "") {
  const value = cleanString(type).toLowerCase();
  if (["pan", "gst", "tin", "vat", "ssn", "ein", "tax_certificate"].includes(value)) return "tax";
  if (["bank_statement", "cancelled_cheque"].includes(value)) return "bank";
  if (["sample_content", "brand_collaboration"].includes(value)) return "content";
  if (["address_proof", "supporting_document"].includes(value)) return "supporting";
  return "identity";
}

function redactDocumentMap(documents = {}) {
  return Object.fromEntries(
    Object.entries(documents || {}).map(([key, value]) => [key, Boolean(value)])
  );
}

async function registerPrivateDocuments({ records = [], assets = [], ownerType = "influencer", ownerId, sourceModel = "InfluencerApplicationDocument" }) {
  if (!records.length || !ownerId || !mongoose.Types.ObjectId.isValid(String(ownerId))) return records;
  const created = await PrivateDocument.insertMany(
    records.map((record, index) => {
      const asset = assets[index] || {};
      return {
        ownerType,
        ownerId,
        documentType: record.documentType,
        category: record.category || documentCategoryFor(record.documentType),
        storageKey: asset.storageKey || record.filePath,
        originalName: record.originalName || asset.originalName || "",
        mimeType: record.mimeType || asset.mimeType || "application/octet-stream",
        size: Number(record.size || asset.size || 0),
        status: record.status === "verified" ? "verified" : "pending",
        sourceModel,
        sourceId: record._id,
      };
    })
  );
  await Promise.all(
    created.map((doc, index) =>
      InfluencerApplicationDocument.updateOne({ _id: records[index]._id }, { $set: { privateDocumentId: doc._id } })
    )
  );
  return records.map((record, index) => ({ ...(record.toObject?.() || record), privateDocumentId: created[index]?._id }));
}


function detectContentNiche(application = {}, socialAccounts = []) {
  const text = [
    application.profileDraft?.primaryCategory,
    application.profileDraft?.customCategory,
    ...(application.profileDraft?.contentNiche || []),
    ...(socialAccounts.map((account) => `${account.platform} ${account.description || ""}`)),
  ].join(" ").toLowerCase();
  const niches = ["technology", "fashion", "gaming", "beauty", "fitness", "education", "lifestyle", "travel", "food", "business"];
  return niches.find((niche) => text.includes(niche)) || "other";
}

async function isEmailTaken(email, excludeApplicationId = "") {
  const normalizedEmail = normalizeEmail(email);
  if (!normalizedEmail) return false;
  const [user, application] = await Promise.all([
    userRepo.findByEmail(normalizedEmail),
    InfluencerApplication.findOne({
      email: normalizedEmail,
      ...(excludeApplicationId ? { applicationId: { $ne: excludeApplicationId } } : {}),
    }).lean(),
  ]);
  return Boolean(user || application);
}

async function isUsernameTaken(username, excludeApplicationId = "") {
  const normalizedUsername = normalizeUsername(username);
  if (!normalizedUsername) return false;
  const application = await InfluencerApplication.findOne({
    username: normalizedUsername,
    ...(excludeApplicationId ? { applicationId: { $ne: excludeApplicationId } } : {}),
  }).lean();
  return Boolean(application);
}

async function getProfileByUserId(userId) {
  return await InfluencerProfile.findOne({ userId }).populate("userId", "name email phone role").exec();
}

class InfluencerService {
  async checkEmail(email) {
    const normalizedEmail = normalizeEmail(email);
    if (!normalizedEmail) throw new AppError("Email is required", 400, "VALIDATION_ERROR");
    const available = !(await isEmailTaken(normalizedEmail));
    return {
      email: normalizedEmail,
      available,
      message: available ? "Available" : "Already registered",
    };
  }

  async checkUsername(username) {
    const normalizedUsername = normalizeUsername(username);
    if (!normalizedUsername) throw new AppError("Username is required", 400, "VALIDATION_ERROR");
    const available = !(await isUsernameTaken(normalizedUsername));
    return {
      username: normalizedUsername,
      available,
      message: available ? "Available" : "Already registered",
    };
  }

  async saveStepOneDraft(payload = {}, meta = {}) {
    const normalizedEmail = normalizeEmail(payload.email);
    const normalizedUsername = normalizeUsername(payload.username);
    const applicationId = cleanString(payload.applicationId) || generateApplicationId();

    const [emailTaken, usernameTaken] = await Promise.all([
      isEmailTaken(normalizedEmail, applicationId),
      isUsernameTaken(normalizedUsername, applicationId),
    ]);
    if (emailTaken) throw new AppError("Email already registered", 409, "EMAIL_EXISTS");
    if (usernameTaken) throw new AppError("Username already registered", 409, "USERNAME_EXISTS");

    const updatePayload = {
      applicationId,
      firstName: cleanString(payload.firstName),
      lastName: cleanString(payload.lastName),
      email: normalizedEmail,
      mobile: cleanString(payload.mobile),
      username: normalizedUsername,
      referralCode: cleanString(payload.referralCode).toUpperCase(),
      status: "draft",
      currentStep: 1,
      termsAccepted: Boolean(payload.termsAccepted),
      privacyAccepted: Boolean(payload.privacyAccepted),
      notificationsAccepted: Boolean(payload.notificationsAccepted),
      "draftMeta.userAgent": cleanString(meta.userAgent),
      "draftMeta.ipAddress": cleanString(meta.ipAddress),
      "draftMeta.lastSavedAt": new Date(),
    };

    if (payload.password) {
      updatePayload.passwordHash = await bcrypt.hash(payload.password, 12);
    }

    const application = await InfluencerApplication.findOneAndUpdate(
      { applicationId },
      { $set: updatePayload },
      {
        upsert: true,
        returnDocument: "after",
        setDefaultsOnInsert: true,
        runValidators: true,
      }
    );

    return {
      application: sanitizeApplication(application),
      nextStep: 2,
      nextPath: "/influencer/register/social-verification",
    };
  }

  async registerStepOne(payload = {}, meta = {}) {
    return this.saveStepOneDraft(payload, meta);
  }

  async saveSocialDraft(payload = {}) {
    const applicationId = cleanString(payload.applicationId);
    if (!applicationId) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const application = await InfluencerApplication.findOne({ applicationId });
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");

    const accounts = Array.isArray(payload.accounts) ? payload.accounts : [];
    validateSocialPayload(accounts);

    const savedAccounts = [];
    for (const account of accounts) {
      const platform = normalizePlatform(account.platform);
      const profileUrl = normalizeUrl(account.profileUrl);
      const verificationStatus = "verified";
      const saved = await InfluencerSocialAccount.findOneAndUpdate(
        { applicationId, platform },
        {
          $set: {
            applicationId,
            platform,
            platformLabel: cleanString(account.platformLabel || account.platform),
            profileUrl,
            username: cleanString(account.username),
            channelName: cleanString(account.channelName),
            accountType: cleanString(account.accountType).toLowerCase(),
            followersCount: Number(account.followersCount || account.subscribers || 0),
            engagementRate: Number(account.engagementRate || 0),
            description: cleanString(account.description),
            metrics: {
              subscribers: Number(account.metrics?.subscribers || account.subscribers || 0),
              averageLikes: Number(account.metrics?.averageLikes || account.averageLikes || 0),
              averageComments: Number(account.metrics?.averageComments || account.averageComments || 0),
              averageViews: Number(account.metrics?.averageViews || account.averageViews || 0),
              contentCount: Number(account.metrics?.contentCount || account.contentCount || 0),
              accountAgeDays: Number(account.metrics?.accountAgeDays || account.accountAgeDays || 0),
              verificationBadge: Boolean(account.metrics?.verificationBadge || account.verificationBadge),
            },
            verificationStatus,
          },
        },
        { upsert: true, returnDocument: "after", setDefaultsOnInsert: true, runValidators: true }
      );
      savedAccounts.push(saved);

      if (account.verificationCode || account.manualProofSubmitted) {
        await InfluencerSocialVerification.findOneAndUpdate(
          { socialAccountId: saved._id, verificationMethod: account.manualProofSubmitted ? "screenshot" : "verification_code" },
          {
            $set: {
              applicationId,
              socialAccountId: saved._id,
              verificationMethod: account.manualProofSubmitted ? "screenshot" : "verification_code",
              verificationCode: account.verificationCode || makeVerificationCode(applicationId, platform),
              status: account.manualProofSubmitted ? "under_review" : "pending",
            },
          },
          { upsert: true, returnDocument: "after", setDefaultsOnInsert: true, runValidators: true }
        );
      }
    }

    await InfluencerApplication.findOneAndUpdate({ applicationId }, { $set: { currentStep: Math.max(application.currentStep || 1, 2), "draftMeta.lastSavedAt": new Date() } });
    const plainAccounts = savedAccounts.map((account) => account.toObject());
    return {
      applicationId,
      accounts: plainAccounts.map(sanitizeSocialAccount),
      creatorScore: calculateCreatorScore(plainAccounts),
      requirements: DEFAULT_SOCIAL_REQUIREMENTS,
    };
  }

  async fetchSocialMetrics(payload = {}) {
    const platform = normalizePlatform(payload.platform);
    const profileUrl = normalizeUrl(payload.profileUrl);
    if (!platform || !profileUrl) throw new AppError("Platform and profile URL are required", 400, "VALIDATION_ERROR");

    const username = extractSocialUsername(platform, profileUrl);
    if (!username) throw new AppError("Could not detect username from profile URL", 400, "VALIDATION_ERROR");

    if (platform === "instagram") {
      const accessToken = process.env.META_GRAPH_ACCESS_TOKEN || process.env.INSTAGRAM_GRAPH_ACCESS_TOKEN;
      const businessAccountId = process.env.INSTAGRAM_BUSINESS_ACCOUNT_ID;
      if (!accessToken || !businessAccountId) {
        return {
          platform,
          profileUrl,
          username,
          available: false,
          source: "manual_fallback",
          message: "Instagram auto-fetch requires Meta Graph API credentials. Enter followers manually or upload proof.",
        };
      }

      try {
        const fields = `business_discovery.username(${username}){username,name,followers_count,media_count}`;
        const response = await axios.get(`https://graph.facebook.com/v19.0/${businessAccountId}`, {
          params: { fields, access_token: accessToken },
          timeout: 8000,
        });
        const discovery = response.data?.business_discovery || {};
        return {
          platform,
          profileUrl,
          username: discovery.username || username,
          channelName: discovery.name || "",
          followersCount: Number(discovery.followers_count || 0),
          contentCount: Number(discovery.media_count || 0),
          engagementRate: 0,
          available: true,
          source: "meta_graph",
          message: "Instagram metrics fetched.",
        };
      } catch (err) {
        return {
          platform,
          profileUrl,
          username,
          available: false,
          source: "meta_graph",
          message: err?.response?.data?.error?.message || "Instagram metrics could not be fetched. Enter followers manually or upload proof.",
        };
      }
    }

    return {
      platform,
      profileUrl,
      username,
      available: false,
      source: "manual_fallback",
      message: "Automatic fetching for this platform is not configured yet.",
    };
  }

  async verifySocial(payload = {}, files = []) {
    const applicationId = cleanString(payload.applicationId);
    const platform = normalizePlatform(payload.platform);
    if (!applicationId || !platform) throw new AppError("Application id and platform are required", 400, "VALIDATION_ERROR");

    const account = await InfluencerSocialAccount.findOne({ applicationId, platform });
    if (!account) throw new AppError("Social account not found", 404, "NOT_FOUND");

    const method = cleanString(payload.verificationMethod || "verification_code");
    const uploaded = files?.length ? await uploadMany(files.slice(0, 1), { folder: "influencer-verifications" }) : [];
    const screenshot = uploaded[0] || null;
    const verificationCode = cleanString(payload.verificationCode) || makeVerificationCode(applicationId, platform);
    const status = method === "screenshot" || screenshot ? "under_review" : "pending";

    const verification = await InfluencerSocialVerification.create({
      applicationId,
      socialAccountId: account._id,
      verificationMethod: screenshot ? "screenshot" : method,
      verificationCode,
      screenshotPath: screenshot?.url || "",
      screenshotMeta: screenshot
        ? {
            originalName: screenshot.originalName,
            mimeType: screenshot.mimeType,
            size: screenshot.size,
          }
        : {},
      status,
    });

    account.verificationStatus = status;
    await account.save();

    return {
      account: sanitizeSocialAccount(account),
      verification: sanitizeVerification(verification),
    };
  }

  async getSocialStatus(applicationId) {
    const id = cleanString(applicationId);
    if (!id) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const accounts = await InfluencerSocialAccount.find({ applicationId: id }).sort({ createdAt: 1 }).lean();
    const verifications = await InfluencerSocialVerification.find({ applicationId: id }).sort({ createdAt: -1 }).lean();
    return {
      applicationId: id,
      accounts: accounts.map(sanitizeSocialAccount),
      verifications: verifications.map(sanitizeVerification),
      creatorScore: calculateCreatorScore(accounts),
      requirements: DEFAULT_SOCIAL_REQUIREMENTS,
      canContinue: accounts.some((account) => account.verificationStatus === "verified" || account.verificationStatus === "under_review"),
    };
  }

  async getSettings(userId) {
    const profile = await InfluencerProfile.findOne({ userId }).lean();
    if (!profile) throw new AppError("Influencer profile not found", 404, "NOT_FOUND");
    
    const [businessProfile, paymentProfile] = await Promise.all([
      InfluencerBusinessProfile.findOne({ influencerId: profile._id }).lean(),
      InfluencerPaymentProfile.findOne({ influencerId: profile._id }).lean()
    ]);
    if (paymentProfile && paymentProfile.additionalBankAccounts) {
      paymentProfile.additionalBankAccounts = paymentProfile.additionalBankAccounts.map(acc => {
        if (acc.upiIdEncrypted) acc.upiId = decryptSensitive(acc.upiIdEncrypted);
        if (acc.paypalEmailEncrypted) acc.paypalEmail = decryptSensitive(acc.paypalEmailEncrypted);
        return acc;
      });
    }

    return {
      ...profile,
      businessProfile: businessProfile || {},
      paymentProfile: paymentProfile || {}
    };
  }

  async updateSettings(userId, payload = {}, files = []) {
    const profile = await InfluencerProfile.findOne({ userId });
    if (!profile) throw new AppError("Influencer profile not found", 404, "NOT_FOUND");

    if (payload.displayName) profile.displayName = String(payload.displayName).substring(0, 100);
    if (payload.shortBio !== undefined) profile.shortBio = String(payload.shortBio).substring(0, 160);
    if (payload.longBio !== undefined) profile.longBio = String(payload.longBio).substring(0, 2000);
    if (payload.bio !== undefined) profile.bio = String(payload.bio).substring(0, 1200);
    if (payload.primaryCategory) profile.primaryCategory = String(payload.primaryCategory);
    
    if (payload.socialHandles) {
      const handles = typeof payload.socialHandles === "string" ? JSON.parse(payload.socialHandles) : payload.socialHandles;
      profile.socialHandles = {
        ...profile.socialHandles,
        ...handles
      };
    }

    if (payload.location) {
      const loc = typeof payload.location === "string" ? JSON.parse(payload.location) : payload.location;
      profile.location = {
        ...profile.location,
        ...loc
      };
    }
    
    if (payload.storeName) profile.storeName = String(payload.storeName).substring(0, 120);
    if (payload.storeSlug) {
      const newSlug = slugify(String(payload.storeSlug));
      if (newSlug !== profile.storeSlug) {
        const [existingProfile, existingApp] = await Promise.all([
          InfluencerProfile.findOne({ storeSlug: newSlug }).select("_id").lean(),
          InfluencerApplication.findOne({ "profileDraft.storeSlug": newSlug }).select("_id").lean(),
        ]);
        if (existingProfile || existingApp) throw new AppError("Store slug is already in use", 400, "SLUG_UNAVAILABLE");
        profile.storeSlug = newSlug;
      }
    }

    if (payload.seo) {
      const seo = typeof payload.seo === "string" ? JSON.parse(payload.seo) : payload.seo;
      profile.seo = {
        ...profile.seo,
        ...seo
      };
    }

    if (payload.preferences) {
      const pref = typeof payload.preferences === "string" ? JSON.parse(payload.preferences) : payload.preferences;
      profile.preferences = {
        ...profile.preferences,
        ...pref
      };
    }

    if (payload.privacy) {
      const priv = typeof payload.privacy === "string" ? JSON.parse(payload.privacy) : payload.privacy;
      profile.privacy = {
        ...profile.privacy,
        ...priv
      };
    }

    if (payload.addressDetails) {
      const address = typeof payload.addressDetails === "string" ? JSON.parse(payload.addressDetails) : payload.addressDetails;
      await InfluencerBusinessProfile.updateOne(
        { influencerId: profile._id },
        {
          $set: {
            country: address.country || "",
            state: address.state || "",
            city: address.city || "",
            address1: address.address1 || "",
            address2: address.address2 || "",
            postalCode: address.postalCode || "",
            phone: address.phone || "",
          }
        },
        { upsert: true }
      );
    }

    if (payload.accountDetails) {
      const account = typeof payload.accountDetails === "string" ? JSON.parse(payload.accountDetails) : payload.accountDetails;
      const paymentUpdate = {
        payoutMethod: account.payoutMethod || "bank_transfer",
        accountHolderName: account.accountHolderName || "",
        bankName: account.bankName || "",
        branchName: account.branchName || "",
        ifscCode: account.ifscCode || "",
        swiftCode: account.swiftCode || "",
        routingNumber: account.routingNumber || "",
      };
      
      if (account.accountNumber && account.accountNumber.indexOf("X") === -1) {
        paymentUpdate.accountNumberEncrypted = encryptSensitive(account.accountNumber);
        paymentUpdate.accountNumberMask = maskAccount(account.accountNumber);
      }
      
      if (account.upiId && account.upiId.indexOf("X") === -1) {
        paymentUpdate.upiIdEncrypted = encryptSensitive(account.upiId);
      }
      
      if (account.paypalEmail && account.paypalEmail.indexOf("X") === -1) {
        paymentUpdate.paypalEmailEncrypted = encryptSensitive(account.paypalEmail);
      }

      if (account.additionalBankAccounts && Array.isArray(account.additionalBankAccounts)) {
        paymentUpdate.additionalBankAccounts = account.additionalBankAccounts.map((acc) => {
          const processedAcc = {
            payoutMethod: acc.payoutMethod || "bank_transfer",
            accountHolderName: acc.accountHolderName || "",
            bankName: acc.bankName || "",
            branchName: acc.branchName || "",
            ifscCode: acc.ifscCode || "",
            swiftCode: acc.swiftCode || "",
            routingNumber: acc.routingNumber || "",
            isPrimary: acc.isPrimary || false,
            accountNumberEncrypted: acc.accountNumberEncrypted || "",
            accountNumberMask: acc.accountNumberMask || "",
            upiIdEncrypted: acc.upiIdEncrypted || "",
            paypalEmailEncrypted: acc.paypalEmailEncrypted || "",
          };

          if (acc.accountNumber && acc.accountNumber.indexOf("X") === -1) {
            processedAcc.accountNumberEncrypted = encryptSensitive(acc.accountNumber);
            processedAcc.accountNumberMask = maskAccount(acc.accountNumber);
          }
          if (acc.upiId && acc.upiId.indexOf("X") === -1) {
            processedAcc.upiIdEncrypted = encryptSensitive(acc.upiId);
          }
          if (acc.paypalEmail && acc.paypalEmail.indexOf("X") === -1) {
            processedAcc.paypalEmailEncrypted = encryptSensitive(acc.paypalEmail);
          }
          
          return processedAcc;
        });
      }
      
      console.log("DEBUG: paymentUpdate before save:", JSON.stringify(paymentUpdate, null, 2));

      await InfluencerPaymentProfile.updateOne(
        { influencerId: profile._id },
        { $set: paymentUpdate },
        { upsert: true }
      );
    }

    const pictureFile = files.find((f) => f.fieldname === "profilePicture");
    if (pictureFile) {
      profile.profilePicture = `/uploads/influencer/profile/${pictureFile.filename}`;
    }

    await profile.save();
    return profile.toObject();
  }

  async checkProfileSlug(slug, applicationId = "") {
    const normalized = slugify(slug);
    if (!normalized) throw new AppError("Store slug is required", 400, "VALIDATION_ERROR");
    const [profile, application] = await Promise.all([
      InfluencerProfile.findOne({ storeSlug: normalized }).select("_id").lean(),
      InfluencerApplication.findOne({
        "profileDraft.storeSlug": normalized,
        ...(applicationId ? { applicationId: { $ne: applicationId } } : {}),
      }).select("_id").lean(),
    ]);
    return {
      slug: normalized,
      available: !profile && !application,
      message: !profile && !application ? "Available" : "Already in use",
    };
  }

  async getProfileDraft(applicationId) {
    const id = cleanString(applicationId);
    if (!id) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const application = await InfluencerApplication.findOne({ applicationId: id }).lean();
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    return sanitizeProfileDraft(application);
  }

  async saveProfileDraft(payload = {}, files = [], { submit = false } = {}) {
    const applicationId = cleanString(payload.applicationId);
    if (!applicationId) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const application = await InfluencerApplication.findOne({ applicationId });
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");

    const groupedFiles = {};
    const fileList = Array.isArray(files)
      ? files
      : Object.values(files || {}).flatMap((entry) => (Array.isArray(entry) ? entry : [entry]).filter(Boolean));
    for (const file of fileList) {
      groupedFiles[file.fieldname] = file;
    }
    const uploaded = {};
    for (const field of ["profilePicture", "coverBanner", "socialSharingImage"]) {
      if (groupedFiles[field]) {
        const [asset] = await uploadMany([groupedFiles[field]], { folder: "influencer-profile" });
        uploaded[field] = asset?.url || "";
      }
    }

    const profile = sanitizeProfileDraftPayload(payload, uploaded);
    if (submit) validateProfileForContinue(profile);
    if (profile.storeSlug) {
      const slugStatus = await this.checkProfileSlug(profile.storeSlug, applicationId);
      if (!slugStatus.available) throw new AppError("Influencer URL slug already in use", 409, "SLUG_EXISTS");
    }

    const updated = await InfluencerApplication.findOneAndUpdate(
      { applicationId },
      {
        $set: {
          profileDraft: profile,
          currentStep: Math.max(Number(application.currentStep || 1), 3),
          "draftMeta.lastSavedAt": new Date(),
        },
      },
      { returnDocument: "after", runValidators: true }
    ).lean();

    return {
      ...sanitizeProfileDraft(updated),
      nextStep: 4,
      nextPath: "/influencer/register/business-information",
    };
  }

  getCountryMaster() {
    return COUNTRY_MASTER;
  }

  getCommissionSettings() {
    return DEFAULT_COMMISSION_SETTINGS;
  }

  async saveBusiness(payload = {}, files = [], { submit = false } = {}) {
    const applicationId = cleanString(payload.applicationId);
    if (!applicationId) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const application = await InfluencerApplication.findOne({ applicationId });
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    const fileList = Array.isArray(files) ? files : Object.values(files || {}).flatMap((entry) => Array.isArray(entry) ? entry : [entry].filter(Boolean));
    const uploaded = {};
    for (const file of fileList) {
      const [asset] = await uploadMany([file], { folder: "influencer-business-documents" });
      uploaded[file.fieldname] = asset?.storageKey || asset?.url || "";
    }
    const business = sanitizeBusinessPayload(payload, uploaded);
    if (submit) validateBusiness(business);

    const saved = await InfluencerBusinessProfile.findOneAndUpdate(
      { applicationId },
      {
        $set: {
          applicationId,
          country: business.country,
          state: business.state,
          city: business.city,
          address1: business.address1,
          address2: business.address2,
          postalCode: business.postalCode,
          businessType: business.businessType,
          customBusinessType: business.customBusinessType,
          gstNumberEncrypted: encryptSensitive(business.gstNumber),
          panNumberEncrypted: encryptSensitive(business.panNumber),
          taxIdEncrypted: encryptSensitive(business.taxId),
          businessRegistrationNumber: business.businessRegistrationNumber,
          legalName: business.legalName,
          businessName: business.businessName,
          dateOfBirth: business.dateOfBirth || undefined,
          nationality: business.nationality,
          documents: { ...(business.documents || {}) },
          status: submit ? "pending" : "draft",
        },
      },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true, runValidators: submit }
    ).lean();
    await InfluencerApplication.updateOne({ applicationId }, { $set: { currentStep: Math.max(Number(application.currentStep || 1), 4), "draftMeta.lastSavedAt": new Date() } });
    return { applicationId, business: saved, nextStep: 5, nextPath: "/influencer/register/payment-commission" };
  }

  async getBusiness(applicationId) {
    const id = cleanString(applicationId);
    if (!id) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    return { applicationId: id, business: await InfluencerBusinessProfile.findOne({ applicationId: id }).lean() };
  }

  async savePayment(payload = {}, { submit = false } = {}) {
    const applicationId = cleanString(payload.applicationId);
    if (!applicationId) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const application = await InfluencerApplication.findOne({ applicationId });
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    const existingPayment = await InfluencerPaymentProfile.findOne({ applicationId }).lean();
    const payment = sanitizePaymentPayload(payload);
    if (submit) validatePayment(payment, existingPayment);
    const accountUpdate = payment.accountNumber
      ? {
          accountNumberEncrypted: encryptSensitive(payment.accountNumber),
          accountNumberMask: maskAccount(payment.accountNumber),
        }
      : {
          accountNumberEncrypted: existingPayment?.accountNumberEncrypted || "",
          accountNumberMask: existingPayment?.accountNumberMask || "",
        };

    const saved = await InfluencerPaymentProfile.findOneAndUpdate(
      { applicationId },
      {
        $set: {
          applicationId,
          payoutMethod: payment.payoutMethod || "bank_transfer",
          accountHolderName: payment.accountHolderName,
          bankName: payment.bankName,
          branchName: payment.branchName,
          ...accountUpdate,
          ifscCode: payment.ifscCode,
          swiftCode: payment.swiftCode,
          routingNumber: payment.routingNumber,
          upiIdEncrypted: encryptSensitive(payment.upiId),
          paypalEmailEncrypted: encryptSensitive(payment.paypalEmail),
          payoneerEmailEncrypted: encryptSensitive(payment.payoneerEmail),
          agreements: payment.agreements,
          commissionSnapshot: DEFAULT_COMMISSION_SETTINGS,
          status: submit ? "pending" : "draft",
        },
      },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true, runValidators: submit }
    ).lean();
    await InfluencerApplication.updateOne({ applicationId }, { $set: { currentStep: Math.max(Number(application.currentStep || 1), 5), "draftMeta.lastSavedAt": new Date() } });
    return { applicationId, payment: saved, commission: DEFAULT_COMMISSION_SETTINGS, nextStep: 6, nextPath: "/influencer/register/content-review" };
  }

  async getPayment(applicationId) {
    const id = cleanString(applicationId);
    if (!id) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const payment = await InfluencerPaymentProfile.findOne({ applicationId: id }).lean();
    return { applicationId: id, payment, commission: DEFAULT_COMMISSION_SETTINGS };
  }

  async saveContentReview(payload = {}, files = [], { submit = false } = {}) {
    const applicationId = cleanString(payload.applicationId);
    if (!applicationId) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const application = await InfluencerApplication.findOne({ applicationId });
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    if (["submitted", "under_review", "approved"].includes(application.status) && submit) {
      throw new AppError("Application has already been submitted", 400, "INVALID_STATE");
    }

    const fileList = Array.isArray(files) ? files : Object.values(files || {}).flatMap((entry) => (Array.isArray(entry) ? entry : [entry].filter(Boolean)));
    const uploadedDocuments = [];
    for (const file of fileList) {
      const documentType = file.fieldname === "identityDocuments" ? "identity_document" : file.fieldname === "brandProofs" ? "brand_collaboration" : "sample_content";
      const [asset] = await uploadMany([file], { folder: "influencer-application-review" });
      if (asset?.storageKey || asset?.url) {
        uploadedDocuments.push({
          applicationId,
          documentType,
          filePath: asset.storageKey || asset.url,
          originalName: file.originalname || "",
          mimeType: file.mimetype || "",
          size: Number(file.size || 0),
          status: documentType === "identity_document" ? "manual_review_required" : "pending",
          ocr: documentType === "identity_document" ? { status: "queued" } : { status: "not_started" },
        });
      }
    }
    if (uploadedDocuments.length) {
      const savedDocuments = await InfluencerApplicationDocument.insertMany(uploadedDocuments);
      await registerPrivateDocuments({
        records: savedDocuments,
        assets: uploadedDocuments.map((document) => ({ storageKey: document.filePath, originalName: document.originalName, mimeType: document.mimeType, size: document.size })),
        ownerId: application.influencerId || application.userId,
      });
    }

    const [socialAccounts, business, payment, documents] = await Promise.all([
      InfluencerSocialAccount.find({ applicationId }).lean(),
      InfluencerBusinessProfile.findOne({ applicationId }).lean(),
      InfluencerPaymentProfile.findOne({ applicationId }).lean(),
      InfluencerApplicationDocument.find({ applicationId }).lean(),
    ]);
    const sampleCount = documents.filter((document) => document.documentType === "sample_content").length;
    const identityCount = documents.filter((document) => document.documentType === "identity_document").length;
    const brandCollaborations = parseJsonArray(payload.brandCollaborations, [])
      .map((item) => ({
        brandName: cleanString(item.brandName).slice(0, 120),
        campaignName: cleanString(item.campaignName).slice(0, 160),
        campaignType: cleanString(item.campaignType).slice(0, 80),
        campaignDate: cleanString(item.campaignDate),
        campaignResults: cleanString(item.campaignResults).slice(0, 500),
      }))
      .filter((item) => item.brandName || item.campaignName);
    const detectedNiche = detectContentNiche(application, socialAccounts);
    const qualityScores = calculateApplicationScore({ application, socialAccounts, business, payment, sampleCount, identityCount });

    if (submit) {
      const missing = [];
      if (!application.profileDraft?.profilePicture || !application.profileDraft?.coverBanner || !application.profileDraft?.displayName) missing.push("Profile information");
      if (!socialAccounts.some((account) => ["verified", "under_review", "manual_review_required", "pending", "draft"].includes(account.verificationStatus))) missing.push("Social verification");
      if (!business || business.status === "draft") missing.push("Business information");
      if (!payment || payment.status === "draft") missing.push("Payment information");
      if (sampleCount < 3) missing.push("At least 3 sample content uploads");
      if (!identityCount) missing.push("Identity document");
      if (missing.length) throw new AppError(`Complete required sections: ${missing.join(", ")}`, 400, "VALIDATION_ERROR", { missing });
    }

    const update = {
      currentStep: 6,
      "draftMeta.lastSavedAt": new Date(),
      creatorScore: qualityScores.overall,
      "contentReview.portfolioUrl": cleanString(payload.portfolioUrl),
      "contentReview.portfolioDescription": cleanString(payload.portfolioDescription).slice(0, 1000),
      "contentReview.detectedNiche": detectedNiche,
      "contentReview.manualNiche": cleanString(payload.manualNiche),
      "contentReview.brandCollaborations": brandCollaborations,
      "contentReview.qualityScores": qualityScores,
      "contentReview.aiReview.status": submit ? "queued" : "not_started",
    };
    if (submit) {
      update.status = "submitted";
      update.reviewStage = "submitted";
      update.submittedAt = new Date();
      update.applicationNumber = application.applicationNumber || generateApplicationNumber();
    }
    const saved = await InfluencerApplication.findOneAndUpdate({ applicationId }, { $set: update }, { returnDocument: "after" }).lean();
    if (submit) {
      await InfluencerApplicationReview.create({
        applicationId,
        decision: "submitted",
        comments: "Application submitted for influencer review.",
        metadata: { creatorScore: qualityScores.overall },
      });
    }
    return await this.getApplicationStatus(applicationId);
  }

  async getApplicationStatus(applicationId) {
    const id = cleanString(applicationId);
    if (!id) throw new AppError("Application id is required", 400, "VALIDATION_ERROR");
    const [application, socialAccounts, business, payment, documents, reviews] = await Promise.all([
      InfluencerApplication.findOne({ applicationId: id }).lean(),
      InfluencerSocialAccount.find({ applicationId: id }).lean(),
      InfluencerBusinessProfile.findOne({ applicationId: id }).lean(),
      InfluencerPaymentProfile.findOne({ applicationId: id }).lean(),
      InfluencerApplicationDocument.find({ applicationId: id }).sort({ createdAt: -1 }).lean(),
      InfluencerApplicationReview.find({ applicationId: id }).sort({ createdAt: -1 }).lean(),
    ]);
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    const stages = ["submitted", "identity_verification", "social_verification", "content_evaluation", "manual_review", "final_decision"];
    const currentIndex = Math.max(0, stages.indexOf(application.reviewStage || "submitted"));
    const registrationSteps = [
      { key: "account_information", label: "Account Information" },
      { key: "social_verification", label: "Social Verification" },
      { key: "profile_information", label: "Profile Information" },
      { key: "business_information", label: "Business Information" },
      { key: "payment_information", label: "Payment Information" },
      { key: "content_review", label: "Content Review" },
    ];
    const stepReviews = reviews.filter((review) => review.metadata?.reviewType === "registration_step");
    return {
      application: sanitizeApplication(application),
      applicationNumber: application.applicationNumber || application.applicationId,
      status: application.status,
      reviewStage: application.reviewStage,
      submittedAt: application.submittedAt,
      estimatedReviewTime: "24-48 Hours",
      creatorScore: application.creatorScore || application.contentReview?.qualityScores?.overall || 0,
      qualityScores: application.contentReview?.qualityScores || {},
      contentReview: application.contentReview || {},
      socialAccounts: socialAccounts.map(sanitizeSocialAccount),
      business: business ? {
        status: business.status,
        country: business.country,
        state: business.state,
        city: business.city,
        address1: business.address1,
        address2: business.address2,
        postalCode: business.postalCode,
        businessType: business.businessType,
        customBusinessType: business.customBusinessType,
        businessRegistrationNumber: business.businessRegistrationNumber,
        legalName: business.legalName,
        businessName: business.businessName,
        dateOfBirth: business.dateOfBirth,
        nationality: business.nationality,
        documents: redactDocumentMap(business.documents),
      } : null,
      payment: payment ? {
        status: payment.status,
        payoutMethod: payment.payoutMethod,
        accountHolderName: payment.accountHolderName,
        bankName: payment.bankName,
        branchName: payment.branchName,
        accountNumberMask: payment.accountNumberMask,
        ifscCode: payment.ifscCode,
        swiftCode: payment.swiftCode,
        routingNumber: payment.routingNumber,
        commissionSnapshot: payment.commissionSnapshot || {},
      } : null,
      documents,
      reviews,
      timeline: stages.map((stage, index) => ({
        stage,
        label: stage.split("_").map((part) => part[0].toUpperCase() + part.slice(1)).join(" "),
        status: index < currentIndex ? "completed" : index === currentIndex ? "current" : "upcoming",
      })),
      stepTimeline: registrationSteps.map((step, index) => {
        const review = stepReviews.find((item) => item.metadata?.stepKey === step.key);
        return {
          ...step,
          status: review?.metadata?.stepDecision || (Number(application.currentStep || 1) > index + 1 ? "completed" : index + 1 === Number(application.currentStep || 1) ? "current" : "upcoming"),
          comments: review?.comments || "",
          reviewedAt: review?.createdAt || null,
        };
      }),
    };
  }

  async listApplications(query = {}) {
    const filters = {};
    if (query.status && query.status !== "all") filters.status = query.status;
    if (query.score === "high") filters.creatorScore = { $gte: 75 };
    if (query.score === "low") filters.creatorScore = { $lt: 50 };
    const sort = query.sort === "oldest" ? { submittedAt: 1, updatedAt: 1 } : { submittedAt: -1, updatedAt: -1 };
    return await InfluencerApplication.find(filters).sort(sort).limit(Math.min(Number(query.limit || 50), 100)).lean();
  }

  async getApplicationReview(applicationId) {
    return await this.getApplicationStatus(applicationId);
  }

  async reviewApplication(applicationId, payload = {}, reviewerId) {
    const id = cleanString(applicationId);
    const decision = cleanString(payload.decision);
    const comments = cleanString(payload.comments);
    const stepKey = cleanString(payload.stepKey);
    const stepDecision = cleanString(payload.stepDecision);
    const application = await InfluencerApplication.findOne({ applicationId: id }).select("+passwordHash");
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    if (application.status === "approved") {
      if (decision === "approve") {
        await this.activateApprovedApplication(id, { reviewerId, comments });
        return await this.getApplicationStatus(id);
      }
      if (!["note", "reject", "suspend"].includes(decision)) {
        throw new AppError("Application is already approved", 409, "APPLICATION_ALREADY_APPROVED");
      }
    }
    if (["rejected", "suspended"].includes(application.status) && decision === "approve") {
      throw new AppError("This application cannot be approved from its current status", 409, "INVALID_APPLICATION_STATE");
    }
    const statusMap = {
      approve: "approved",
      reject: "rejected",
      request_changes: "requires_changes",
      suspend: "suspended",
      request_documents: "pending_documents",
      note: application.status,
    };
    const nextStatus = statusMap[decision];
    if (!nextStatus) throw new AppError("Invalid review decision", 400, "VALIDATION_ERROR");

    const update = {
      status: nextStatus,
      reviewStage: decision === "note" ? application.reviewStage : decision === "approve" || decision === "reject" ? "final_decision" : "manual_review",
      reviewedAt: new Date(),
      reviewNotes: comments || application.reviewNotes || "",
    };
    if (decision === "approve") update.approvedAt = new Date();
    if (decision === "reject") update.rejectedAt = new Date();

    const updated = await InfluencerApplication.findOneAndUpdate({ applicationId: id }, { $set: update }, { returnDocument: "after" });
    await InfluencerApplicationReview.create({
      applicationId: id,
      reviewerId,
      decision,
      comments,
      metadata: {
        previousStatus: application.status,
        nextStatus,
        ...(stepKey && stepDecision ? { reviewType: "registration_step", stepKey, stepDecision } : {}),
      },
    });

    if (decision === "approve") await this.activateApprovedApplication(id, { reviewerId, comments });
    if (["reject", "suspend"].includes(decision) && application.status === "approved") await this.revokeApprovedInfluencer(id, { reviewerId, comments, decision });

    return await this.getApplicationStatus(id);
  }

  async revokeApprovedInfluencer(applicationId, { reviewerId = null, comments = "", decision = "reject" } = {}) {
    const application = await InfluencerApplication.findOne({ applicationId }).lean();
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    const user = await userRepo.findByEmail(application.email);
    if (!user) return null;
    const profile = await InfluencerProfile.findOne({ userId: user._id });
    if (!profile) return null;

    await InfluencerProfile.updateOne(
      { _id: profile._id },
      {
        $set: {
          state: "suspended",
          verified: false,
          permissions: {
            dashboard: false,
            storefront: false,
            affiliateLinks: false,
            collections: false,
            wallet: false,
            campaigns: false,
          },
          "moderation.notes": comments,
        },
      }
    );
    await Promise.all([
      InfluencerBadge.updateMany({ influencerId: profile._id, status: "active" }, { $set: { status: "revoked", revokedAt: new Date() } }),
      InfluencerStorefront.updateOne({ influencerId: profile._id }, { $set: { status: "suspended" } }),
      InfluencerAffiliateSetting.updateOne({ influencerId: profile._id }, { $set: { status: "suspended" } }),
      InfluencerWallet.updateOne({ influencerId: profile._id }, { $set: { status: "suspended" } }),
    ]);

    const remainingRoles = Array.from(new Set([user.role, ...(user.roles || [])].filter(Boolean))).filter((role) => role !== "influencer");
    await userRepo.updateById(user._id, {
      role: user.role === "influencer" ? remainingRoles[0] || "user" : user.role,
      roles: remainingRoles.length ? remainingRoles : ["user"],
    });
    await writeActivationAudit({ applicationId, influencerId: profile._id, actorId: reviewerId, action: decision === "suspend" ? "INFLUENCER_SUSPENDED" : "INFLUENCER_REVOKED", status: "success", metadata: { comments } });
    return profile;
  }

  async activateApprovedApplication(applicationId, { reviewerId = null, comments = "" } = {}) {
    const application = await InfluencerApplication.findOne({ applicationId }).select("+passwordHash");
    if (!application) throw new AppError("Influencer application not found", 404, "NOT_FOUND");
    if (application.status !== "approved") throw new AppError("Application must be approved before activation", 400, "INVALID_STATE");
    const profileDraft = application.profileDraft || {};
    const now = new Date();

    const [emailUser, phoneUser] = await Promise.all([
      userRepo.findByEmail(application.email),
      userRepo.findByPhone(application.mobile),
    ]);
    if (emailUser && phoneUser && String(emailUser._id) !== String(phoneUser._id)) {
      throw new AppError("Application email and mobile belong to different existing accounts. Request changes before approval.", 409, "ACCOUNT_CONFLICT");
    }
    let user = emailUser || phoneUser;
    if (!user) {
      user = await userRepo.createUser({
        name: `${application.firstName} ${application.lastName}`.trim(),
        email: application.email,
        phone: application.mobile,
        password: application.passwordHash,
        role: "influencer",
        roles: ["influencer"],
        status: "active",
      });
      await writeActivationAudit({ applicationId, actorId: reviewerId, action: "ACCOUNT_CREATED", status: "success", metadata: { userId: user._id } });
    } else if (!user.email && application.email) {
      user = await userRepo.updateById(user._id, { email: application.email });
    } else if (![user.role, ...(user.roles || [])].includes("influencer")) {
      user = await userRepo.updateById(user._id, { roles: Array.from(new Set([user.role, ...(user.roles || []), "influencer"].filter(Boolean))), status: "active" });
      await writeActivationAudit({ applicationId, actorId: reviewerId, action: "INFLUENCER_ACCESS_ASSIGNED", status: "success", metadata: { userId: user._id, primaryRolePreserved: user.role } });
    }

    const existingProfile = await InfluencerProfile.findOne({ userId: user._id }).lean();
    const influencerCode = existingProfile?.influencerCode || await ensureUniqueInfluencerCode();
    const storeSlug = existingProfile?.storeSlug || await ensureUniqueStoreSlug(profileDraft.storeSlug || profileDraft.displayName || application.username, user._id);
    const profile = await InfluencerProfile.findOneAndUpdate(
      { userId: user._id },
      {
        $set: {
          userId: user._id,
          state: "active",
          verified: true,
          influencerCode,
          followers: 0,
          permissions: {
            dashboard: true,
            storefront: true,
            affiliateLinks: true,
            collections: true,
            wallet: true,
            campaigns: true,
          },
          profilePicture: profileDraft.profilePicture || "",
          coverBanner: profileDraft.coverBanner || "",
          displayName: profileDraft.displayName || `${application.firstName} ${application.lastName}`.trim(),
          shortBio: profileDraft.shortBio || "",
          longBio: profileDraft.longBio || "",
          primaryCategory: profileDraft.primaryCategory || "",
          customCategory: profileDraft.customCategory || "",
          secondaryCategories: profileDraft.secondaryCategories || [],
          languages: profileDraft.languages || [],
          location: { country: profileDraft.country || "", state: profileDraft.state || "", city: profileDraft.city || "" },
          website: profileDraft.website || "",
          contentNiche: profileDraft.contentNiche || [],
          contentStyle: profileDraft.contentStyle || [],
          storeName: profileDraft.storeName || profileDraft.displayName || "",
          storeSlug,
          seo: {
            metaTitle: profileDraft.metaTitle || "",
            metaDescription: profileDraft.metaDescription || "",
            socialSharingImage: profileDraft.socialSharingImage || "",
          },
          "activation.activatedAt": now,
          "activation.checklist.bannerUploaded": Boolean(profileDraft.coverBanner),
          "activation.checklist.profilePhotoUploaded": Boolean(profileDraft.profilePicture),
          "activation.checklist.bioCompleted": Boolean(profileDraft.shortBio),
          "moderation.submittedAt": application.submittedAt,
          "moderation.verifiedAt": now,
          "moderation.notes": comments,
        },
      },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
    );
    await writeActivationAudit({ applicationId, influencerId: profile._id, actorId: reviewerId, action: "PROFILE_ACTIVATED", status: "success", metadata: { influencerCode } });

    const badgeType = Number(application.creatorScore || 0) >= 80 ? "gold_verified" : "creator_verified";
    await InfluencerBadge.findOneAndUpdate(
      { influencerId: profile._id, status: "active" },
      { $setOnInsert: { influencerId: profile._id, badgeType, label: badgeType === "gold_verified" ? "Gold Verified Creator" : "Verified Influencer", issuedAt: now } },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
    );
    await writeActivationAudit({ applicationId, influencerId: profile._id, actorId: reviewerId, action: "BADGE_ISSUED", status: "success", metadata: { badgeType } });

    await InfluencerStorefront.findOneAndUpdate(
      { influencerId: profile._id },
      {
        $set: {
          influencerId: profile._id,
          slug: storeSlug,
          name: profile.storeName || profile.displayName,
          banner: profile.coverBanner || "",
          profileImage: profile.profilePicture || "",
          description: profile.shortBio || profile.longBio || "",
          socialLinks: application.contentReview?.portfolioUrl ? { portfolio: application.contentReview.portfolioUrl } : {},
          categories: [profile.primaryCategory, ...(profile.secondaryCategories || [])].filter(Boolean),
          status: "active",
        },
      },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
    );
    await writeActivationAudit({ applicationId, influencerId: profile._id, actorId: reviewerId, action: "STOREFRONT_CREATED", status: "success", metadata: { slug: storeSlug } });

    const existingAffiliate = await InfluencerAffiliateSetting.findOne({ influencerId: profile._id }).lean();
    const trackingCode = existingAffiliate?.trackingCode || await ensureUniqueTrackingCode(application.username);
    await InfluencerAffiliateSetting.findOneAndUpdate(
      { influencerId: profile._id },
      {
        $setOnInsert: {
          influencerId: profile._id,
          trackingCode,
          commissionType: "percentage",
          commissionRate: DEFAULT_COMMISSION_SETTINGS.commissionPercentage,
          status: "active",
        },
      },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
    );
    await writeActivationAudit({ applicationId, influencerId: profile._id, actorId: reviewerId, action: "AFFILIATE_ENABLED", status: "success", metadata: { trackingCode } });

    await InfluencerCollection.findOneAndUpdate(
      { influencerId: profile._id, slug: "creator-favorites" },
      { $setOnInsert: { influencerId: profile._id, title: "Creator Favorites", slug: "creator-favorites", type: "creator_favorites", featured: true, status: "active" } },
      { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
    );
    await InfluencerWallet.findOneAndUpdate({ influencerId: profile._id }, { $setOnInsert: { influencerId: profile._id, status: "active" }, $set: { status: "active" } }, { upsert: true, returnDocument: "after", setDefaultsOnInsert: true });
    await writeActivationAudit({ applicationId, influencerId: profile._id, actorId: reviewerId, action: "WALLET_ACTIVATED", status: "success" });

    await InfluencerApplication.updateOne({ applicationId }, { $set: { approvedAt: application.approvedAt || now, reviewStage: "final_decision" } });
    await emitDomainEvent(INFLUENCER_EVENTS.INFLUENCER_ACTIVATED, { influencerId: profile._id, userId: user._id, applicationId });
    return await this.getActivationWelcome(profile._id);
  }

  async getActivationWelcome(influencerId) {
    const [profile, badge, storefront, affiliate, wallet, collections] = await Promise.all([
      InfluencerProfile.findById(influencerId).lean(),
      InfluencerBadge.findOne({ influencerId, status: "active" }).lean(),
      InfluencerStorefront.findOne({ influencerId }).lean(),
      InfluencerAffiliateSetting.findOne({ influencerId }).lean(),
      InfluencerWallet.findOne({ influencerId }).lean(),
      InfluencerCollection.find({ influencerId, status: "active" }).lean(),
    ]);
    const checklist = profile?.activation?.checklist || {};
    const checks = [
      checklist.bannerUploaded,
      checklist.profilePhotoUploaded,
      checklist.bioCompleted,
      checklist.firstCollectionCreated || collections.length > 0,
      checklist.firstAffiliateLinkGenerated,
      checklist.storefrontShared,
    ];
    return {
      profile,
      badge,
      storefront,
      affiliate,
      wallet,
      collections,
      checklist,
      completionPercentage: Math.round((checks.filter(Boolean).length / checks.length) * 100),
      capabilities: {
        badgeActivated: Boolean(badge),
        storefrontCreated: Boolean(storefront),
        affiliateLinksEnabled: Boolean(affiliate),
        productCollectionsEnabled: true,
        commissionWalletActivated: Boolean(wallet),
      },
    };
  }

  async register(userId, payload = {}) {
    const user = await userRepo.findById(userId);
    if (!user) throw new AppError("User not found", 404, "NOT_FOUND");
    if (user.role !== "influencer") {
      await userRepo.updateById(userId, { role: "influencer" });
    }

    const nextState = payload.submit ? "submitted" : "draft";
    const profile = await InfluencerProfile.findOneAndUpdate(
      { userId },
      {
        $set: {
          categories: payload.categories || [],
          followers: Number(payload.followers || 0),
          bio: payload.bio || "",
          socialHandles: payload.socialHandles || {},
          state: nextState,
          ...(payload.submit ? { "moderation.submittedAt": new Date() } : {}),
        },
      },
      {
        upsert: true,
        returnDocument: "after",
        setDefaultsOnInsert: true,
        runValidators: true,
      }
    ).populate("userId", "name email phone role");

    return profile;
  }

  async getProfile(userId) {
    const profile = await getProfileByUserId(userId);
    if (!profile) throw new AppError("Influencer profile not found", 404, "NOT_FOUND");
    return profile;
  }

  async listAffiliateProducts(userId, query = {}) {
    const profile = await this.getProfile(userId);
    if (!profile.permissions?.affiliateLinks) throw new AppError("Affiliate products are not enabled", 403, "FORBIDDEN");
    const affiliate = await InfluencerAffiliateSetting.findOne({ influencerId: profile._id }).lean();
    const page = Math.max(1, Number(query.page) || 1);
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 12));
    const skip = (page - 1) * limit;
    const eligible = await getEligiblePromotionProductContext(profile._id);
    let eligibleProductIds = eligible.productIds;
    const filter = { _id: { $in: eligibleProductIds }, status: "APPROVED", isActive: true };
    if (query.category) filter.category = cleanString(query.category);
    if (query.vendor) filter.sellerId = query.vendor;
    if (query.availability === "in_stock") filter.stock = { $gt: 0 };
    if (query.search) {
      const re = new RegExp(escapeRegex(query.search), "i");
      filter.$or = [{ name: re }, { SKU: re }, { category: re }, { tags: re }];
    }
    if (query.minPrice || query.maxPrice) {
      filter.price = {};
      if (query.minPrice) filter.price.$gte = Number(query.minPrice);
      if (query.maxPrice) filter.price.$lte = Number(query.maxPrice);
    }
    if (query.mode === "new") {
      const since = new Date();
      since.setUTCDate(since.getUTCDate() - 45);
      filter.createdAt = { $gte: since };
    }
    const sortMap = {
      best_selling: { "analytics.salesCount": -1, createdAt: -1 },
      trending: { "analytics.views": -1, "analytics.salesCount": -1 },
      highest_rated: { "ratings.averageRating": -1, "ratings.totalReviews": -1 },
      newest: { createdAt: -1 },
      most_viewed: { "analytics.views": -1 },
    };
    const sort = sortMap[query.sort] || (query.mode === "new" ? sortMap.newest : sortMap.best_selling);
    const [items, total] = await Promise.all([
      Product.find(filter)
        .populate("sellerId", "shopName companyName")
        .select("name SKU category categoryId tags price discountPrice currency stock status isActive images thumbnail sellerId analytics ratings createdAt")
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      Product.countDocuments(filter),
    ]);
    let rows = await Promise.all(items.map(async (product) => {
      const row = await enrichAffiliateProduct(product, { affiliate });
      const promotion = eligible.byProduct.get(String(product._id)) || {};
      return {
        ...row,
        vendorId: promotion.vendorId || product.sellerId?._id || product.sellerId,
        vendor: promotion.vendorName || row.vendor,
        campaignId: promotion.campaignId || "",
        campaignName: promotion.campaignName || "",
        campaignStatus: promotion.campaignStatus || "",
        promotionStatus: promotion.promotionStatus || "approved",
        assignmentSource: promotion.source || "",
      };
    }));
    if (query.mode === "highest_commission" || query.sort === "highest_commission") rows = rows.sort((a, b) => b.commissionAmount - a.commissionAmount);
    return {
      items: rows,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit) || 1,
    };
  }

  async generateAffiliateProductLinks(userId, payload = {}) {
    const profile = await this.getProfile(userId);
    const productIds = Array.isArray(payload.productIds) ? payload.productIds.filter(Boolean).slice(0, 50) : payload.productId ? [payload.productId] : [];
    const links = [];
    for (const productId of productIds) {
      const promotion = await assertPromotionProductAllowed(profile._id, productId, payload.campaignId || "");
      const product = await Product.findById(productId).select("_id slug productNumber sellerId").lean();
      if (!product) continue;
      const targetPath = `/product/${product._id}`;
      const generated = await this.generateAffiliateLink(userId, {
        targetType: "product",
        targetPath,
        productId,
        campaignId: promotion.campaignId || payload.campaignId || "",
      });
      const params = new URLSearchParams();
      if (payload.utmSource) params.set("utm_source", payload.utmSource);
      if (payload.utmMedium) params.set("utm_medium", payload.utmMedium);
      if (payload.utmCampaign) params.set("utm_campaign", payload.utmCampaign);
      if (payload.utmContent) params.set("utm_content", payload.utmContent);
      if (payload.utmTerm) params.set("utm_term", payload.utmTerm);
      const suffix = params.toString() ? `${generated.trackingUrl.includes("?") ? "&" : "?"}${params.toString()}` : "";
      const affiliateUrl = `${generated.trackingUrl}${suffix}`;
      await AffiliateLink.findOneAndUpdate(
        { influencerId: profile._id, productId, campaignId: promotion.campaignId || undefined },
        {
          $set: {
            influencerId: profile._id,
            productId,
            campaignId: promotion.campaignId || undefined,
            vendorId: product.sellerId || promotion.vendorId,
            affiliateCode: generated.trackingCode,
            targetPath,
            affiliateUrl,
            status: "active",
            generatedAt: new Date(),
          },
        },
        { upsert: true, returnDocument: "after", setDefaultsOnInsert: true }
      );
      links.push({ productId, campaignId: promotion.campaignId || "", originalUrl: targetPath, affiliateUrl, shortLink: affiliateUrl, qrValue: affiliateUrl });
    }
    return { links };
  }

  async listCollectionProducts(userId, query = {}) {
    const profile = await this.getProfile(userId);
    if (!profile.permissions?.collections) throw new AppError("Collections are not enabled", 403, "FORBIDDEN");
    const page = Math.max(1, Number(query.page) || 1);
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 12));
    const skip = (page - 1) * limit;
    const eligible = await getEligiblePromotionProductContext(profile._id);
    const filter = { _id: { $in: eligible.productIds }, status: "APPROVED", isActive: true };
    if (query.category) filter.category = cleanString(query.category);
    if (query.vendor) filter.sellerId = query.vendor;
    if (query.search) {
      const search = new RegExp(cleanString(query.search).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      filter.$or = [{ name: search }, { SKU: search }, { category: search }, { tags: search }];
    }
    if (query.minPrice || query.maxPrice) {
      filter.price = {};
      if (query.minPrice) filter.price.$gte = Number(query.minPrice);
      if (query.maxPrice) filter.price.$lte = Number(query.maxPrice);
    }
    const [items, total] = await Promise.all([
      Product.find(filter)
        .populate("sellerId", "shopName companyName")
        .select("name SKU category tags price discountPrice currency stock status isActive images thumbnail sellerId analytics ratings")
        .sort({ "analytics.salesCount": -1, createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Product.countDocuments(filter),
    ]);
    const collection = query.collectionId
      ? await InfluencerCollection.findOne({ _id: query.collectionId, influencerId: profile._id }).select("productIds").lean()
      : null;
    const assigned = new Set((collection?.productIds || []).map(String));
    return {
      items: items.map((product) => ({
        id: String(product._id),
        name: product.name,
        image: productImage(product),
        brand: product.sellerId?.shopName || product.sellerId?.companyName || "",
        category: product.category,
        price: product.discountPrice || product.price,
        basePrice: product.price,
        commission: 0,
        status: product.status,
        stock: product.stock,
        rating: product.ratings?.averageRating || 0,
        assigned: assigned.has(String(product._id)),
      })),
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit) || 1,
    };
  }

  async listCollections(userId, query = {}) {
    const profile = await this.getProfile(userId);
    if (!profile.permissions?.collections) throw new AppError("Collections are not enabled", 403, "FORBIDDEN");
    const page = Math.max(1, Number(query.page) || 1);
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 12));
    const skip = (page - 1) * limit;
    const filter = { influencerId: profile._id };
    if (query.status) filter.status = normalizeCollectionStatus(query.status);
    if (query.type) filter.type = normalizeCollectionType(query.type);
    if (query.featured === "true") filter.featured = true;
    if (query.search) {
      const search = new RegExp(cleanString(query.search).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      filter.$or = [{ title: search }, { slug: search }, { tags: search }, { description: search }];
    }
    const [items, total] = await Promise.all([
      InfluencerCollection.find(filter)
        .populate("productIds", "name images thumbnail category price discountPrice analytics ratings")
        .sort({ featured: -1, "display.priority": -1, updatedAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      InfluencerCollection.countDocuments(filter),
    ]);
    return {
      items: items.map((collection) => ({
        ...collection,
        productsCount: collection.productIds?.length || 0,
        analyticsSummary: collectionAnalyticsSnapshot(collection),
      })),
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit) || 1,
    };
  }

  async getCollection(userId, collectionId) {
    const profile = await this.getProfile(userId);
    const collection = await InfluencerCollection.findOne({ _id: collectionId, influencerId: profile._id })
      .populate("productIds", "name SKU images thumbnail category price discountPrice currency stock status analytics ratings")
      .lean();
    if (!collection) throw new AppError("Collection not found", 404, "NOT_FOUND");
    return { ...collection, productsCount: collection.productIds?.length || 0, analyticsSummary: collectionAnalyticsSnapshot(collection) };
  }

  async saveCollection(userId, payload = {}, collectionId = null) {
    const profile = await this.getProfile(userId);
    if (!profile.permissions?.collections) throw new AppError("Collections are not enabled", 403, "FORBIDDEN");
    const title = cleanString(payload.title || payload.name);
    if (!title) throw new AppError("Collection name is required", 400, "VALIDATION_ERROR");
    const nextSlug = slugify(payload.slug || title);
    const existing = await InfluencerCollection.findOne({
      influencerId: profile._id,
      slug: nextSlug,
      ...(collectionId ? { _id: { $ne: collectionId } } : {}),
    }).lean();
    if (existing) throw new AppError("Collection slug already exists", 409, "DUPLICATE_SLUG");
    const eligible = await getEligiblePromotionProductContext(profile._id);
    const productIds = Array.isArray(payload.productIds) ? payload.productIds.filter((productId) => eligible.byProduct.has(String(productId))).slice(0, 100) : [];
    const status = normalizeCollectionStatus(payload.status);
    if (status === "active" && productIds.length < 1) {
      throw new AppError("Published collections require at least one product", 400, "MINIMUM_PRODUCTS_REQUIRED");
    }
    const type = normalizeCollectionType(payload.type);
    const update = {
      influencerId: profile._id,
      title,
      slug: nextSlug,
      description: cleanString(payload.description).slice(0, 1200),
      type,
      tags: normalizeTags(payload.tags),
      productIds,
      productOrder: productIds.map((productId, index) => ({ productId, position: index, pinned: false })),
      featured: Boolean(payload.featured) || type === "featured",
      status,
      media: {
        coverImage: cleanString(payload.coverImage || payload.media?.coverImage),
        bannerImage: cleanString(payload.bannerImage || payload.media?.bannerImage),
        thumbnail: cleanString(payload.thumbnail || payload.media?.thumbnail),
      },
      display: {
        layout: payload.display?.layout || payload.layout || "grid",
        placement: Array.isArray(payload.display?.placement) ? payload.display.placement : ["storefront_homepage"],
        priority: Number(payload.display?.priority || payload.priority || 0),
        pinned: Boolean(payload.display?.pinned || payload.pinned),
      },
      visibility: {
        audience: payload.visibility?.audience || payload.audience || "public",
        locations: Array.isArray(payload.visibility?.locations) ? payload.visibility.locations : ["storefront_homepage"],
        startDate: payload.visibility?.startDate || payload.startDate || undefined,
        endDate: payload.visibility?.endDate || payload.endDate || undefined,
        timezone: payload.visibility?.timezone || payload.timezone || "UTC",
        rules: payload.visibility?.rules || {},
      },
      seo: {
        metaTitle: cleanString(payload.seo?.metaTitle || payload.metaTitle).slice(0, 160),
        metaDescription: cleanString(payload.seo?.metaDescription || payload.metaDescription).slice(0, 300),
        canonicalUrl: cleanString(payload.seo?.canonicalUrl || payload.canonicalUrl),
        openGraphImage: cleanString(payload.seo?.openGraphImage || payload.openGraphImage),
        keywords: normalizeTags(payload.seo?.keywords || payload.keywords),
      },
      seasonal: {
        season: cleanString(payload.seasonal?.season || payload.season),
        template: cleanString(payload.seasonal?.template || payload.template),
        autoPublish: Boolean(payload.seasonal?.autoPublish || payload.autoPublish),
        autoExpire: Boolean(payload.seasonal?.autoExpire || payload.autoExpire),
      },
    };
    const collection = collectionId
      ? await InfluencerCollection.findOneAndUpdate({ _id: collectionId, influencerId: profile._id }, { $set: update }, { returnDocument: "after", runValidators: true })
      : await InfluencerCollection.create(update);
    if (!collection) throw new AppError("Collection not found", 404, "NOT_FOUND");
    await InfluencerProfile.updateOne({ _id: profile._id }, { $set: { "activation.checklist.firstCollectionCreated": true } });
    await writeActivationAudit({
      influencerId: profile._id,
      actorId: profile.userId,
      action: collectionId ? "COLLECTION_UPDATED" : "COLLECTION_CREATED",
      status: "success",
      metadata: { collectionId: collection._id, slug: collection.slug, status: collection.status },
    });
    return await this.getCollection(userId, collection._id);
  }

  async updateCollectionStatus(userId, collectionId, payload = {}) {
    const profile = await this.getProfile(userId);
    const update = {};
    if (payload.status) update.status = normalizeCollectionStatus(payload.status);
    if (payload.featured !== undefined) update.featured = Boolean(payload.featured);
    if (payload.priority !== undefined) update["display.priority"] = Number(payload.priority || 0);
    if (payload.visibility) Object.keys(payload.visibility).forEach((key) => { update[`visibility.${key}`] = payload.visibility[key]; });
    const collection = await InfluencerCollection.findOneAndUpdate({ _id: collectionId, influencerId: profile._id }, { $set: update }, { returnDocument: "after", runValidators: true });
    if (!collection) throw new AppError("Collection not found", 404, "NOT_FOUND");
    await writeActivationAudit({ influencerId: profile._id, actorId: profile.userId, action: "COLLECTION_VISIBILITY_UPDATED", status: "success", metadata: { collectionId, update } });
    return collection;
  }

  async deleteCollection(userId, collectionId) {
    const profile = await this.getProfile(userId);
    if (!profile.permissions?.collections) throw new AppError("Collections are not enabled", 403, "FORBIDDEN");
    const collection = await InfluencerCollection.findOneAndDelete({ _id: collectionId, influencerId: profile._id });
    if (!collection) throw new AppError("Collection not found", 404, "NOT_FOUND");
    await Promise.all([
      InfluencerStorefront.updateMany(
        { influencerId: profile._id },
        { $pull: { featuredCollectionIds: collection._id } }
      ),
      writeActivationAudit({
        influencerId: profile._id,
        actorId: profile.userId,
        action: "COLLECTION_DELETED",
        status: "success",
        metadata: { collectionId: collection._id, slug: collection.slug },
      }),
    ]);
    return { id: String(collection._id), deleted: true };
  }

  async assignCollectionProducts(userId, collectionId, payload = {}) {
    const profile = await this.getProfile(userId);
    const collection = await InfluencerCollection.findOne({ _id: collectionId, influencerId: profile._id });
    if (!collection) throw new AppError("Collection not found", 404, "NOT_FOUND");
    const current = new Set((collection.productIds || []).map(String));
    const eligible = await getEligiblePromotionProductContext(profile._id);
    const incoming = (Array.isArray(payload.productIds) ? payload.productIds : []).filter(Boolean).map(String);
    if (payload.mode === "remove") incoming.forEach((id) => current.delete(id));
    else if (payload.mode === "replace") {
      current.clear();
      incoming.filter((id) => eligible.byProduct.has(String(id))).forEach((id) => current.add(id));
    } else incoming.filter((id) => eligible.byProduct.has(String(id))).forEach((id) => current.add(id));
    const productIds = Array.from(current).slice(0, 100);
    collection.productIds = productIds;
    collection.productOrder = productIds.map((productId, index) => ({ productId, position: index, pinned: false }));
    await collection.save();
    await writeActivationAudit({ influencerId: profile._id, actorId: profile.userId, action: "COLLECTION_PRODUCTS_UPDATED", status: "success", metadata: { collectionId, mode: payload.mode || "add", productIds: incoming } });
    return await this.getCollection(userId, collectionId);
  }

  async getCollectionAnalytics(userId, query = {}) {
    const profile = await this.getProfile(userId);
    const filter = { influencerId: profile._id };
    if (query.collectionId) filter._id = query.collectionId;
    if (query.type) filter.type = normalizeCollectionType(query.type);
    const collections = await InfluencerCollection.find(filter).populate("productIds", "name analytics price discountPrice").lean();
    const totals = collections.reduce((acc, collection) => {
      const row = collectionAnalyticsSnapshot(collection);
      Object.keys(row).forEach((key) => { acc[key] = Number(acc[key] || 0) + Number(row[key] || 0); });
      return acc;
    }, {});
    const productIds = collections.flatMap((collection) => collection.productIds || []).map((product) => product._id || product);
    const commissionRows = productIds.length
      ? await CommissionRecord.aggregate([
          { $match: { influencerId: profile._id } },
          { $group: { _id: "$state", revenue: { $sum: "$gross" }, commission: { $sum: "$influencerShare" }, orders: { $sum: 1 } } },
        ])
      : [];
    const trend = Array.from({ length: 14 }).map((_, index) => {
      const date = new Date();
      date.setUTCDate(date.getUTCDate() - (13 - index));
      return { date: date.toISOString().slice(0, 10), views: 0, clicks: 0, revenue: 0, conversion: 0 };
    });
    return {
      totals,
      collections: collections.map((collection) => ({ id: collection._id, title: collection.title, productsCount: collection.productIds?.length || 0, ...collectionAnalyticsSnapshot(collection) })),
      productPerformance: collections.flatMap((collection) => (collection.productIds || []).map((product) => ({
        id: String(product._id),
        collectionId: String(collection._id),
        name: product.name,
        revenue: Number(product.analytics?.totalRevenue || 0),
        orders: Number(product.analytics?.salesCount || 0),
        views: Number(product.analytics?.views || 0),
      }))).slice(0, 20),
      commissionRows,
      trend,
    };
  }

  async getStorefront({ slug = "", username = "", userId = "", tab = "storefront", filter = "", search = "", page = 1, limit = 24 } = {}) {
    let storefront;
    const publicSlug = slugify(slug || username);
    if (publicSlug) {
      storefront = await InfluencerStorefront.findOne({ slug: publicSlug, status: "active" })
        .populate("featuredProductIds", publicProductSelect())
        .populate("featuredCollectionIds", "title slug description media analytics productIds featured status type")
        .lean();
      if (!storefront) {
        const profileBySlug = await InfluencerProfile.findOne({
          $or: [{ storeSlug: publicSlug }, { influencerCode: cleanString(slug || username) }],
          state: "active",
          "privacy.profileVisibility": "public",
        }).select("_id").lean();
        if (profileBySlug) {
          storefront = await InfluencerStorefront.findOne({ influencerId: profileBySlug._id, status: "active" })
            .populate("featuredProductIds", publicProductSelect())
            .populate("featuredCollectionIds", "title slug description media analytics productIds featured status type")
            .lean();
        }
      }
    }
    if (!storefront && !publicSlug && userId) {
      const profile = await this.getProfile(userId);
      storefront = await InfluencerStorefront.findOne({ influencerId: profile._id })
        .populate("featuredProductIds", publicProductSelect())
        .populate("featuredCollectionIds", "title slug description media analytics productIds featured status type")
        .lean();
    }
    if (!storefront) throw new AppError("Influencer storefront not found", 404, "NOT_FOUND");
    const pageNumber = Math.max(1, Number(page) || 1);
    const pageLimit = Math.min(60, Math.max(1, Number(limit) || 24));
    const collectionFilter = {
      influencerId: storefront.influencerId,
      status: "active",
      "visibility.audience": { $in: ["public", "scheduled"] },
      $and: [
        { $or: [{ "visibility.startDate": { $exists: false } }, { "visibility.startDate": null }, { "visibility.startDate": { $lte: new Date() } }] },
        { $or: [{ "visibility.endDate": { $exists: false } }, { "visibility.endDate": null }, { "visibility.endDate": { $gte: new Date() } }] },
      ],
    };
    const textSearch = cleanString(search);
    if (filter) collectionFilter.type = filter;
    if (textSearch) {
      const re = new RegExp(textSearch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      collectionFilter.$or = [{ title: re }, { description: re }, { tags: re }];
    }
    const reelFilter = {
      influencerId: storefront.influencerId,
      visibility: "published",
      state: { $in: ["approved", "published"] },
      campaignId: { $exists: true, $ne: null },
    };
    if (textSearch) {
      const re = new RegExp(textSearch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      reelFilter.$or = [{ title: re }, { caption: re }, { description: re }, { tags: re }];
    }
    const postFilter = { influencerId: storefront.influencerId, visibility: "published", "productIds.0": { $exists: true } };
    if (textSearch) {
      const re = new RegExp(textSearch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      postFilter.$or = [{ caption: re }, { tags: re }];
    }
    const sortByFilter = filter === "popular"
      ? { "metrics.views": -1, publishedAt: -1 }
      : filter === "trending"
        ? { "metrics.likes": -1, "metrics.views": -1, publishedAt: -1 }
        : { publishedAt: -1, createdAt: -1 };
    const eligible = await getEligiblePromotionProductContext(storefront.influencerId);
    const eligibleProductIds = eligible.productIds;
    collectionFilter.productIds = { $in: eligibleProductIds };
    reelFilter.productIds = { $in: eligibleProductIds };
    postFilter.productIds = { $in: eligibleProductIds };
    const [profile, user, badge, collections, allCollectionCount, reels, reelCount, posts, postCount, homepageLayout, affiliate, socialAccounts, followerCount, isFollowing, followingCount, commissionTotals] = await Promise.all([
      InfluencerProfile.findById(storefront.influencerId).lean(),
      InfluencerProfile.findById(storefront.influencerId).select("userId").populate("userId", "name email avatarUrl").lean().then((row) => row?.userId || null),
      InfluencerBadge.findOne({ influencerId: storefront.influencerId, status: "active" }).lean(),
      InfluencerCollection.find(collectionFilter)
        .populate("productIds", publicProductSelect())
        .sort({ featured: -1, "display.priority": -1, updatedAt: -1 })
        .skip(tab === "collections" ? (pageNumber - 1) * pageLimit : 0)
        .limit(tab === "collections" ? pageLimit : 12)
        .lean(),
      InfluencerCollection.countDocuments(collectionFilter),
      Reel.find(reelFilter)
        .populate({ path: "productIds", select: publicProductSelect() })
        .sort(tab === "reels" ? sortByFilter : { publishedAt: -1, createdAt: -1 })
        .skip(tab === "reels" ? (pageNumber - 1) * pageLimit : 0)
        .limit(tab === "reels" ? pageLimit : 10)
        .lean(),
      Reel.countDocuments(reelFilter),
      InfluencerPost.find(postFilter)
        .populate("productIds", publicProductSelect())
        .populate("collectionIds", "title slug media")
        .sort(tab === "posts" ? sortByFilter : { publishedAt: -1, createdAt: -1 })
        .skip(tab === "posts" ? (pageNumber - 1) * pageLimit : 0)
        .limit(tab === "posts" ? pageLimit : 12)
        .lean(),
      InfluencerPost.countDocuments(postFilter),
      homepageLayoutService.getSharedInfluencerLayout({ device: "desktop" }).catch(() => null),
      InfluencerAffiliateSetting.findOne({ influencerId: storefront.influencerId, status: "active" }).lean(),
      InfluencerSocialAccount.find({ influencerId: storefront.influencerId, verificationStatus: { $in: ["verified", "pending", "under_review"] } }).lean(),
      InfluencerFollower.countDocuments({ influencerId: storefront.influencerId }),
      userId ? InfluencerFollower.exists({ influencerId: storefront.influencerId, customerId: userId }) : null,
      InfluencerFollower.countDocuments({ customerId: storefront.influencerId }).catch(() => 0),
      CommissionRecord.aggregate([
        { $match: { influencerId: storefront.influencerId } },
        { $group: { _id: null, orders: { $sum: 1 }, revenue: { $sum: "$gross" }, commission: { $sum: "$influencerShare" } } },
      ]).catch(() => []),
    ]);
    const featuredProducts = (storefront.featuredProductIds || []).filter((product) => product?.status === "APPROVED" && product?.isActive !== false && eligible.byProduct.has(String(product._id || product)));
    const profileStats = compactProfileStats({
      profile,
      reels,
      followerCount,
      followingCount,
      orderCount: commissionTotals?.[0]?.orders || profile?.stats?.sales || 0,
    });
    const publicUsername = storefront.slug || profile?.storeSlug || publicSlug;
    const seo = {
      title: storefront.seo?.metaTitle || profile?.seo?.metaTitle || `${profile?.displayName || user?.name || storefront.name} - Creator Storefront`,
      description: storefront.seo?.metaDescription || profile?.seo?.metaDescription || storefront.description || profile?.shortBio || "",
      canonicalUrl: storefront.seo?.canonicalUrl || `/influencer/${publicUsername}`,
      openGraphTitle: storefront.seo?.openGraphTitle || storefront.seo?.metaTitle || storefront.name,
      openGraphDescription: storefront.seo?.openGraphDescription || storefront.seo?.metaDescription || storefront.description || "",
      openGraphImage: storefront.seo?.openGraphImage || storefront.banner || profile?.coverBanner || "",
      twitterCard: "summary_large_image",
      structuredData: buildStructuredData({ profile, user, storefront, collections, featuredProducts }),
    };

    await Promise.all([
      InfluencerProfile.updateOne({ _id: storefront.influencerId }, { $inc: { "stats.views": 1 } }).catch(() => null),
      InfluencerStorefront.updateOne({ _id: storefront._id }, { $inc: { "analytics.views": 1 } }).catch(() => null),
      InfluencerStorefrontEvent.create({
        influencerId: storefront.influencerId,
        storefrontId: storefront._id,
        userId: userId || null,
        eventType: tab === "storefront" ? "storefront_view" : "profile_view",
        surface: `influencer-${tab || "storefront"}`,
      }).catch(() => null),
    ]);

    return {
      storefront,
      profile: {
        ...profile,
        username: publicUsername,
        email: storefront.contact?.email || user?.email || "",
        avatarUrl: profile?.profilePicture || storefront.profileImage || user?.avatarUrl || "",
        name: profile?.displayName || user?.name || storefront.name,
      },
      user,
      badge,
      collections,
      reels,
      posts,
      featuredProducts,
      affiliate,
      socialLinks: collectPublicSocialLinks(storefront, profile, socialAccounts),
      stats: profileStats,
      viewer: {
        isFollowing: Boolean(isFollowing),
        isOwner: Boolean(userId && profile?.userId && String(profile.userId) === String(userId)),
      },
      tabs: {
        active: tab || "storefront",
        counts: { collections: allCollectionCount, reels: reelCount, posts: postCount },
      },
      pagination: {
        page: pageNumber,
        limit: pageLimit,
        total: tab === "collections" ? allCollectionCount : tab === "reels" ? reelCount : tab === "posts" ? postCount : 0,
      },
      homepageLayout,
      containers: homepageLayout?.containers || [],
      route: `/influencer/${publicUsername}`,
      seo,
      recommendations: {
        products: featuredProducts.slice(0, 8),
        collections: collections.slice(0, 6),
        reels: reels.slice(0, 8),
        posts: posts.slice(0, 8),
      },
    };
  }

  async followPublicStorefront(username, userId, source = "storefront") {
    if (!userId) throw new AppError("Login required to follow creators", 401, "UNAUTHORIZED");
    const data = await this.getStorefront({ slug: username, userId });
    const influencerId = data.storefront.influencerId;
    if (String(data.profile?.userId || "") === String(userId)) throw new AppError("You cannot follow your own creator profile", 400, "INVALID_OPERATION");
    const existing = await InfluencerFollower.findOne({ influencerId, customerId: userId });
    if (existing) return { following: true, followers: data.stats.followers };
    await InfluencerFollower.create({ influencerId, customerId: userId, source });
    await Promise.all([
      InfluencerProfile.updateOne({ _id: influencerId }, { $inc: { followers: 1 } }),
      InfluencerStorefrontEvent.create({
        influencerId,
        storefrontId: data.storefront._id,
        userId,
        eventType: "follow",
        surface: source || "storefront",
      }).catch(() => null),
      notificationService.createNotification({
        userId: data.profile.userId,
        role: "INFLUENCER",
        module: "GROWTH",
        subModule: "INFLUENCER_COMMERCE",
        type: "INFLUENCER_COMMERCE",
        title: "New follower",
        message: "A customer followed your creator profile.",
        referenceId: userId,
        meta: { followerId: userId, influencerId, storefrontId: data.storefront._id },
      }).catch(() => null),
    ]);
    const followers = await InfluencerFollower.countDocuments({ influencerId });
    return { following: true, followers };
  }

  async unfollowPublicStorefront(username, userId) {
    if (!userId) throw new AppError("Login required to unfollow creators", 401, "UNAUTHORIZED");
    const data = await this.getStorefront({ slug: username, userId });
    const deleted = await InfluencerFollower.findOneAndDelete({ influencerId: data.storefront.influencerId, customerId: userId });
    if (deleted) {
      await Promise.all([
        InfluencerProfile.updateOne({ _id: data.storefront.influencerId, followers: { $gt: 0 } }, { $inc: { followers: -1 } }),
        InfluencerStorefrontEvent.create({
          influencerId: data.storefront.influencerId,
          storefrontId: data.storefront._id,
          userId,
          eventType: "unfollow",
          surface: "storefront",
        }).catch(() => null),
      ]);
    }
    const followers = await InfluencerFollower.countDocuments({ influencerId: data.storefront.influencerId });
    return { following: false, followers };
  }

  async subscribePublicNewsletter(username, payload = {}) {
    const data = await this.getStorefront({ slug: username });
    const email = normalizeEmail(payload.email);
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new AppError("A valid email is required", 400, "VALIDATION_ERROR");
    await InfluencerNewsletterSubscription.findOneAndUpdate(
      { influencerId: data.storefront.influencerId, email },
      { $set: { status: "active", source: payload.source || "storefront", subscribedAt: new Date() } },
      { upsert: true, returnDocument: "after" }
    );
    await InfluencerStorefrontEvent.create({
      influencerId: data.storefront.influencerId,
      storefrontId: data.storefront._id,
      eventType: "newsletter_subscribe",
      surface: "influencer-storefront",
      metadata: { email },
    }).catch(() => null);
    return { subscribed: true, email };
  }

  async trackPublicEvent(username, userId, payload = {}) {
    const data = await this.getStorefront({ slug: username, userId });
    const allowed = new Set(["profile_view", "storefront_view", "product_view", "product_click", "add_to_cart", "collection_view", "reel_view", "post_view", "post_engagement", "social_click", "newsletter_subscribe", "follow", "unfollow", "carousel_view", "carousel_navigation", "share", "search", "profile_report", "profile_block"]);
    const eventType = allowed.has(payload.eventType) ? payload.eventType : "profile_view";
    const metadata = payload.metadata || {};
    await InfluencerStorefrontEvent.create({
      influencerId: data.storefront.influencerId,
      storefrontId: data.storefront._id,
      userId: userId || null,
      anonymousId: cleanString(payload.anonymousId || ""),
      eventType,
      surface: payload.surface || "influencer-storefront",
      productId: payload.productId || undefined,
      collectionId: payload.collectionId || undefined,
      reelId: payload.reelId || undefined,
      postId: payload.postId || undefined,
      metadata,
    });

    if (payload.postId) {
      const metricByAction = {
        like: "metrics.likes",
        unlike: "metrics.likes",
        comment: "metrics.comments",
        share: "metrics.shares",
        save: "metrics.saves",
        unsave: "metrics.saves",
        click: "metrics.clicks",
        view: "metrics.views",
      };
      const action = cleanString(metadata.action || "");
      const metricPath = metricByAction[action] || (eventType === "share" ? "metrics.shares" : "");
      if (metricPath) {
        const decrement = action === "unlike" || action === "unsave";
        await InfluencerPost.updateOne(
          { _id: payload.postId, influencerId: data.storefront.influencerId },
          { $inc: { [metricPath]: decrement ? -1 : 1 } }
        ).catch(() => null);
      }
    }
    return { tracked: true };
  }

  async generateAffiliateLink(userId, payload = {}) {
    const profile = await this.getProfile(userId);
    if (!profile.permissions?.affiliateLinks) throw new AppError("Affiliate links are not enabled", 403, "FORBIDDEN");
    const affiliate = await InfluencerAffiliateSetting.findOne({ influencerId: profile._id, status: "active" }).lean();
    if (!affiliate) throw new AppError("Affiliate settings are not active", 400, "AFFILIATE_NOT_ACTIVE");
    const targetType = cleanString(payload.targetType || "product");
    const targetPath = cleanString(payload.targetPath || payload.url || "");
    if (!targetPath) throw new AppError("Target path is required", 400, "VALIDATION_ERROR");
    let targetProductId = payload.productId || "";
    if (targetType === "product" && !targetProductId) {
      const productKey = targetPath.match(/\/product\/([^/?#]+)/)?.[1] || "";
      if (productKey) {
        const product = await Product.findOne({
          $or: [
            ...(mongoose.isValidObjectId(productKey) ? [{ _id: productKey }] : []),
            { slug: productKey },
            { productNumber: productKey },
          ],
        }).select("_id").lean();
        targetProductId = product?._id || "";
      }
    }
    if (targetType === "product" && targetProductId) {
      await assertPromotionProductAllowed(profile._id, targetProductId, payload.campaignId || "");
    } else if (targetType === "product") {
      throw new AppError("Product affiliate links require an assigned or approved product", 403, "PRODUCT_NOT_APPROVED_FOR_INFLUENCER");
    }
    const normalizedPath = targetPath.startsWith("/") ? targetPath : `/${targetPath}`;
    const trackingUrl = `/ref/${affiliate.trackingCode}${normalizedPath}`;
    await InfluencerProfile.updateOne({ _id: profile._id }, { $set: { "activation.checklist.firstAffiliateLinkGenerated": true } });
    await writeActivationAudit({ influencerId: profile._id, action: "AFFILIATE_LINK_GENERATED", status: "success", metadata: { targetType, targetPath: normalizedPath, trackingUrl } });
    return { trackingCode: affiliate.trackingCode, targetType, targetPath: normalizedPath, trackingUrl };
  }

  async getProfileById(profileId) {
    const profile = await InfluencerProfile.findById(profileId).populate("userId", "name email phone role").exec();
    if (!profile) throw new AppError("Influencer profile not found", 404, "NOT_FOUND");
    return profile;
  }

  async list(query = {}, userId = "") {
    const filters = {};
    if (query.state) filters.state = query.state;
    if (query.category) filters.categories = query.category;
    if (query.verified !== undefined) filters.verified = query.verified === "true";
    if (query.followingOnly === "true" || query.followedOnly === "true") {
      if (!userId) return [];
      const followedRows = await InfluencerFollower.find({ customerId: userId }).select("influencerId").lean();
      filters._id = { $in: followedRows.map((row) => row.influencerId) };
    }

    const rows = await InfluencerProfile.find(filters)
      .populate("userId", "name email phone")
      .sort({ verified: -1, followers: -1, createdAt: -1 })
      .lean();
    if (!rows.length) return rows;

    const influencerIds = rows.map((row) => row._id);
    const [followerCounts, followedRows] = await Promise.all([
      InfluencerFollower.aggregate([
        { $match: { influencerId: { $in: influencerIds } } },
        { $group: { _id: "$influencerId", count: { $sum: 1 } } },
      ]),
      userId ? InfluencerFollower.find({ influencerId: { $in: influencerIds }, customerId: userId }).select("influencerId").lean() : [],
    ]);
    const countMap = new Map(followerCounts.map((row) => [String(row._id), row.count]));
    const followedSet = new Set(followedRows.map((row) => String(row.influencerId)));
    return rows.map((row) => ({
      ...row,
      followers: countMap.get(String(row._id)) ?? row.followers ?? 0,
      isFollowing: followedSet.has(String(row._id)),
    }));
  }

  async moderate(profileId, payload = {}) {
    const profile = await InfluencerProfile.findById(profileId);
    if (!profile) throw new AppError("Influencer profile not found", 404, "NOT_FOUND");

    const update = {
      verified: payload.state === "verified" || payload.state === "active",
      state: payload.state,
      "moderation.notes": payload.notes || profile.moderation?.notes || "",
    };

    if (payload.state === "verified" || payload.state === "active") {
      update["moderation.verifiedAt"] = new Date();
    }
    if (payload.state === "suspended") {
      update["moderation.suspendedAt"] = new Date();
    }

    const updated = await InfluencerProfile.findByIdAndUpdate(profileId, { $set: update }, { returnDocument: "after" }).populate(
      "userId",
      "name email phone role"
    );

    if (payload.state === "active") {
      await emitDomainEvent(INFLUENCER_EVENTS.INFLUENCER_ACTIVATED, {
        influencerId: updated._id,
        userId: updated.userId?._id || updated.userId,
      });
    }

    return updated;
  }
}

module.exports = new InfluencerService();
