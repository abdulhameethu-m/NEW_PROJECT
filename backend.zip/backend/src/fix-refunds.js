const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });

async function syncRefunds() {
  try {
    const mongoUri = process.env.MONGODB_URI || "mongodb://localhost:27017/grm-ecommerce";
    await mongoose.connect(mongoUri);
    console.log("Connected to DB.");

    const Order = mongoose.model("Order", new mongoose.Schema({}, { strict: false }));
    const Refund = mongoose.model("Refund", new mongoose.Schema({}, { strict: false }));

    const refundedOrders = await Order.find({ 
      status: "Refunded",
      "refundSummary.amount": { $in: [0, null, undefined] }
    });

    console.log(`Found ${refundedOrders.length} orders lacking refund amounts.`);

    let fixed = 0;
    for (const order of refundedOrders) {
        let amount = order.totalAmount;
        // See if we can find a refund record
        const refundRecord = await Refund.findOne({ orderId: order._id });
        if (refundRecord && refundRecord.amount) {
            amount = refundRecord.amount;
        }

        await Order.updateOne({ _id: order._id }, {
            $set: {
                "refundSummary.status": "REFUNDED",
                "refundSummary.amount": Number(amount || 0),
                "refundSummary.method": refundRecord?.refundMethod || "ONLINE",
            }
        });
        fixed++;
    }

    console.log(`Fixed ${fixed} orders. Done!`);
  } catch (err) {
    console.error(err);
  } finally {
    process.exit(0);
  }
}

syncRefunds();
